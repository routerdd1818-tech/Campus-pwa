import React, { createContext, useContext, useState, useEffect, useMemo, useRef } from 'react';
import {
  Course,
  Todo,
  Transaction,
  Installment,
  RecurringItem,
  CountdownItem,
  CountdownTodoItem,
  SavingsJar,
  SavingsDeposit,
  CourseGradeItem,
  GraduationTarget,
  SplitBill,
  DebtRecord,
  DebtRepayment,
  UserSettings,
  UserAccount,
  CalendarEvent,
  SavedFriendRecord,
  SharedScheduleData,
  CustomCategory,
  ClassPeriod,
  GpaScale,
  StockHoldingItem,
  AssetAccount,
  BalanceAdjustmentRecord,
  SurvivalBudgetSettings,
  CourseWishlistItem,
} from '../types';
import { DEFAULT_CLASS_PERIODS } from '../components/PeriodSettingsModal';
import { batchFetchStockPrices, fetchStockPrice } from '../services/stockService';

import {
  fetchCoursesFromSupabase,
  upsertCourseToSupabase,
  deleteCourseFromSupabase,
  batchUpsertCoursesToSupabase,
  fetchTodosFromSupabase,
  upsertTodoToSupabase,
  deleteTodoFromSupabase,
  batchUpsertTodosToSupabase,
  fetchTransactionsFromSupabase,
  upsertTransactionToSupabase,
  deleteTransactionFromSupabase,
  batchUpsertTransactionsToSupabase,
  fetchCalendarEventsFromSupabase,
  upsertCalendarEventToSupabase,
  deleteCalendarEventFromSupabase,
  batchUpsertCalendarEventsToSupabase,
  syncAllLocalDataToSupabase,
  saveUserLineBotPushSettings,
  publishSharedSchedule,
  fetchSharedScheduleByCode,
  loginUserAccount,
  updateUserAccountDisplayName,
  rateFriendTransaction,
  toUUID,
  DEFAULT_SUPABASE_URL,
  DEFAULT_SUPABASE_ANON_KEY,
} from '../services/supabase';
import {
  startPwaNotificationScheduler,
  notifySharedCalendarChange,
} from '../services/notificationService';

// 預設示範課程資料
const INITIAL_COURSES: Course[] = [
  {
    id: 'c1',
    name: '演算法分析與設計',
    code: 'CS301',
    classroom: '工程館 302',
    instructor: '陳教授',
    dayOfWeek: 1,
    startTime: '09:00',
    endTime: '12:00',
    colorHex: '#E67E22',
  },
  {
    id: 'c2',
    name: '作業系統',
    code: 'CS305',
    classroom: '電資大樓 105',
    instructor: '林教授',
    dayOfWeek: 2,
    startTime: '13:30',
    endTime: '16:20',
    colorHex: '#3D2F2E',
  },
  {
    id: 'c3',
    name: '人工智慧導論',
    code: 'AI401',
    classroom: '資訊館 201',
    instructor: '黃教授',
    dayOfWeek: 3,
    startTime: '10:10',
    endTime: '12:00',
    colorHex: '#48BB78',
  },
  {
    id: 'c4',
    name: '軟體工程專題',
    code: 'CS410',
    classroom: '創客教室 A',
    instructor: '張教授',
    dayOfWeek: 4,
    startTime: '14:00',
    endTime: '17:00',
    colorHex: '#ED8936',
  },
  {
    id: 'c5',
    name: '電腦網路概論',
    code: 'CS308',
    classroom: '工程館 101',
    instructor: '李教授',
    dayOfWeek: 5,
    startTime: '09:00',
    endTime: '11:00',
    colorHex: '#4A3E3D',
  },
];

const INITIAL_TODOS: Todo[] = [
  {
    id: 't_travel',
    title: '12/7~12/14 日本東京自由行 (度假出遊)',
    startDate: '2026-12-07',
    endDate: '2026-12-14',
    dueDate: '2026-12-07T08:00:00.000Z',
    isCompleted: false,
    priority: 'high',
    category: '出國/旅遊',
    recurrence: 'custom_period',
    notes: '護照換日幣、成田特快 Skyliner 車票、Bic Camera 優惠券',
  },
  {
    id: 't1',
    title: '演算法作業二：動態規劃解題',
    dueDate: new Date(Date.now() + 86400000 * 2).toISOString(),
    isCompleted: false,
    priority: 'high',
    category: '作業',
  },
  {
    id: 't2',
    title: '作業系統小考範圍複習第 4-6 章',
    dueDate: new Date(Date.now() + 86400000 * 4).toISOString(),
    isCompleted: false,
    priority: 'medium',
    category: '考試',
  },
  {
    id: 't3',
    title: '閱讀 Attention Is All You Need 論文',
    isCompleted: true,
    priority: 'low',
    category: '論文閱讀',
    readingStatus: '已讀畢',
  },
];


const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx1',
    amount: 120,
    type: 'expense',
    categoryName: '餐飲',
    categoryIcon: 'coffee',
    categoryColorHex: '#E67E22',
    paymentMethodName: 'LINE Pay',
    date: new Date().toISOString(),
    notes: '學餐排骨飯 + 綠茶',
    valueScore: 9,
  },
  {
    id: 'tx2',
    amount: 65,
    type: 'expense',
    categoryName: '交通',
    categoryIcon: 'bus',
    categoryColorHex: '#48BB78',
    paymentMethodName: '悠遊卡',
    date: new Date(Date.now() - 86400000).toISOString(),
    notes: '捷運通學來回',
    valueScore: 8,
  },
];

const INITIAL_CALENDAR_EVENTS: CalendarEvent[] = [
  {
    id: 'e1',
    title: '期中考週 (Midterms)',
    startDate: new Date(Date.now() + 86400000 * 4).toISOString().slice(0, 10),
    endDate: new Date(Date.now() + 86400000 * 8).toISOString().slice(0, 10),
    isAllDay: true,
    colorHex: '#E67E22',
    category: '考試',
    notes: '全校期中考週，自習室 24H 開放',
    isSharedWithFriends: true,
  },
  {
    id: 'e2',
    title: '系學會秋季露營 (Camping Trip)',
    startDate: new Date(Date.now() + 86400000 * 11).toISOString().slice(0, 10),
    endDate: new Date(Date.now() + 86400000 * 13).toISOString().slice(0, 10),
    isAllDay: true,
    colorHex: '#48BB78',
    category: '活動',
    notes: '南投清境農場，攜帶保暖衣物',
    isSharedWithFriends: true,
  },
  {
    id: 'e3',
    title: '軟體專題期末成果發表',
    startDate: new Date(Date.now() + 86400000 * 16).toISOString().slice(0, 10),
    endDate: new Date(Date.now() + 86400000 * 16).toISOString().slice(0, 10),
    startTime: '13:30',
    endTime: '17:00',
    isAllDay: false,
    colorHex: '#3182CE',
    category: '專案',
    notes: '創客教室 A，準備簡報與 Demo 影片',
    isSharedWithFriends: true,
  },
];

export const DEFAULT_EXPENSE_CATEGORIES: CustomCategory[] = [
  { id: 'cat_food', name: '餐飲', icon: 'coffee', colorHex: '#E67E22' },
  { id: 'cat_trans', name: '交通', icon: 'bus', colorHex: '#48BB78' },
  { id: 'cat_study', name: '學習', icon: 'book', colorHex: '#3182CE' },
  { id: 'cat_life', name: '生活', icon: 'shopping-cart', colorHex: '#805AD5' },
  { id: 'cat_ent', name: '娛樂', icon: 'gamepad-2', colorHex: '#D53F8C' },
  { id: 'cat_tech', name: '數位 3C', icon: 'laptop', colorHex: '#3D2F2E' },
  { id: 'cat_other', name: '其他', icon: 'more-horizontal', colorHex: '#718096' },
];

export const DEFAULT_INCOME_CATEGORIES: CustomCategory[] = [
  { id: 'inc_allowance', name: '生活費', icon: 'home', colorHex: '#48BB78' },
  { id: 'inc_salary', name: '薪資/家教', icon: 'briefcase', colorHex: '#3182CE' },
  { id: 'inc_scholarship', name: '獎學金', icon: 'award', colorHex: '#ECC94B' },
  { id: 'inc_other', name: '其他收入', icon: 'dollar-sign', colorHex: '#805AD5' },
];

export const DEFAULT_TODO_CATEGORIES: CustomCategory[] = [
  { id: 'todo_hw', name: '作業', colorHex: '#E67E22' },
  { id: 'todo_exam', name: '考試', colorHex: '#E53E3E' },
  { id: 'todo_report', name: '報告', colorHex: '#3182CE' },
  { id: 'todo_life', name: '生活', colorHex: '#48BB78' },
  { id: 'todo_personal', name: '個人', colorHex: '#805AD5' },
  { id: 'todo_paper', name: '論文閱讀', colorHex: '#3D2F2E' },
  { id: 'todo_trip', name: '出國/旅遊', colorHex: '#DD6B20' },
];

export const DEFAULT_RECURRING_ITEMS: RecurringItem[] = [
  {
    id: 'rec_rent',
    title: '租屋套房房租',
    amount: 8500,
    type: 'expense',
    dayOfMonth: 5,
    categoryName: '居住房租',
    emoji: '🏠',
    colorHex: '#3B82F6',
    paymentMethodName: '郵局轉帳',
    isActive: true,
    autoRecord: false,
    notes: '每月5號前匯款給房東',
  },
  {
    id: 'rec_netflix',
    title: 'Netflix 家庭方案',
    amount: 130,
    type: 'expense',
    dayOfMonth: 15,
    categoryName: '休閒娛樂',
    emoji: '🍿',
    colorHex: '#EF4444',
    paymentMethodName: '信用卡',
    isActive: true,
    autoRecord: false,
    notes: '室友4人分攤',
  },
  {
    id: 'rec_salary',
    title: '校內助理助學金',
    amount: 6000,
    type: 'income',
    dayOfMonth: 20,
    categoryName: '薪資收入',
    emoji: '🎓',
    colorHex: '#10B981',
    paymentMethodName: '銀行帳戶',
    isActive: true,
    autoRecord: false,
    notes: '實驗室專案助學金',
  },
];

export const DEFAULT_INSTALLMENTS: Installment[] = [
  {
    id: 'inst_macbook',
    title: 'M3 MacBook Air 筆電',
    totalAmount: 36000,
    totalPeriods: 12,
    paidPeriods: 4,
    periodAmount: 3000,
    startDate: '2026-06-10',
    billingDay: 10,
    paymentMethodName: '玉山信用卡',
    emoji: '💻',
    colorHex: '#6366F1',
    notes: '學業程式開發分期，12期0利率',
    isCompleted: false,
  },
];

export const DEFAULT_COUNTDOWNS: CountdownItem[] = [
  {
    id: 'cd_grad',
    title: '大學畢業典禮',
    targetDate: '2027-06-20',
    mode: 'countdown',
    emoji: '🎓',
    category: 'life',
    colorHex: '#F59E0B',
    isPinned: true,
    notes: '一起拍學士服合照！',
  },
  {
    id: 'cd_love',
    title: '與另一半在一起',
    targetDate: '2026-05-20',
    mode: 'countup',
    emoji: '💖',
    category: 'anniversary',
    colorHex: '#EC4899',
    isPinned: true,
    notes: '珍惜相伴的每一天',
  },
  {
    id: 'cd_finals',
    title: '期末考週結束',
    targetDate: '2027-01-15',
    mode: 'countdown',
    emoji: '📝',
    category: 'exam',
    colorHex: '#10B981',
    isPinned: false,
    notes: '歐趴衝刺！',
    todos: [
      { id: 'ct_1', title: '計量經濟考古題 110-113', isCompleted: true },
      { id: 'ct_2', title: '機器學習作業二提交', isCompleted: false },
      { id: 'ct_3', title: '總體經濟學筆記整理', isCompleted: false },
    ],
  },
];

export const DEFAULT_SAVINGS_JARS: SavingsJar[] = [
  {
    id: 'jar_japan',
    title: '日本畢業旅行基金',
    emoji: '✈️',
    colorHex: '#3B82F6',
    targetAmount: 25000,
    currentAmount: 12400,
    targetDate: '2027-06-01',
    deposits: [
      { id: 'dep_1', amount: 10000, date: '2026-09-10', note: '暑假打工存款' },
      { id: 'dep_2', amount: 2400, date: '2026-10-05', note: '家教獎金投入' },
    ],
    isCompleted: false,
    notes: '東京五天四夜自由行！',
  },
  {
    id: 'jar_ipad',
    title: 'iPad Air 筆記平板',
    emoji: '💻',
    colorHex: '#8B5CF6',
    targetAmount: 18900,
    currentAmount: 6500,
    targetDate: '2027-02-15',
    deposits: [
      { id: 'dep_3', amount: 6500, date: '2026-10-01', note: '初始儲蓄金' },
    ],
    isCompleted: false,
    notes: '上課無紙化筆記用',
  },
];

export const DEFAULT_GRADUATION_TARGET: GraduationTarget = {
  totalTarget: 128,
  requiredTarget: 72,
  electiveTarget: 36,
  generalTarget: 20,
};

export const DEFAULT_COURSE_GRADES: CourseGradeItem[] = [
  {
    id: 'cg_algo',
    semester: '115-1',
    courseName: '資料結構與演算法',
    emoji: '💻',
    colorHex: '#3B82F6',
    credits: 3,
    category: 'required',
    attendanceWeight: 30,
    midtermWeight: 30,
    finalWeight: 40,
    attendanceScore: 88,
    midtermScore: 56,
    finalScore: null,
    isPassed: true,
  },
  {
    id: 'cg_os',
    semester: '115-1',
    courseName: '作業系統概論',
    emoji: '⚙️',
    colorHex: '#8B5CF6',
    credits: 3,
    category: 'required',
    attendanceWeight: 25,
    midtermWeight: 35,
    finalWeight: 40,
    attendanceScore: 92,
    midtermScore: 74,
    finalScore: null,
    isPassed: true,
  },
  {
    id: 'cg_ai',
    semester: '115-1',
    courseName: '生成式 AI 實務專題',
    emoji: '🤖',
    colorHex: '#10B981',
    credits: 3,
    category: 'elective',
    attendanceWeight: 40,
    midtermWeight: 30,
    finalWeight: 30,
    attendanceScore: 95,
    midtermScore: 88,
    finalScore: 90,
    isPassed: true,
  },
];

export const DEFAULT_ASSET_ACCOUNTS: AssetAccount[] = [
  {
    id: 'acc_cash',
    name: '錢包現金',
    type: 'cash',
    balance: 3850,
    emoji: '💵',
    colorHex: '#10B981',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'acc_bank_richart',
    name: '台新Richart存款',
    type: 'bank',
    balance: 26500,
    emoji: '🏦',
    colorHex: '#3B82F6',
    accountNumber: '8812',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'acc_bank_esun',
    name: '玉山銀行存款',
    type: 'bank',
    balance: 14200,
    emoji: '💳',
    colorHex: '#14B8A6',
    accountNumber: '3351',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'acc_stock',
    name: '台美股投資證券戶',
    type: 'stock',
    balance: 50500,
    emoji: '📈',
    colorHex: '#F59E0B',
    stocks: [
      {
        id: 'stk_0050',
        symbol: '0050.TW',
        name: '元大台灣50',
        shares: 200,
        currentPrice: 195.5,
        currency: 'TWD',
        lastPriceUpdated: new Date().toISOString(),
      },
      {
        id: 'stk_00878',
        symbol: '00878.TW',
        name: '國泰永續高股息',
        shares: 500,
        currentPrice: 22.8,
        currency: 'TWD',
        lastPriceUpdated: new Date().toISOString(),
      },
    ],
    updatedAt: new Date().toISOString(),
  },
];

export const DEFAULT_SURVIVAL_SETTINGS: SurvivalBudgetSettings = {
  monthlyBudget: 12000,
  emergencyReserve: 3000,
  includeCash: true,
  includeBank: true,
  includeReceivables: false,
  includeStocks: false,
};

export const DEFAULT_COURSE_WISHLIST: CourseWishlistItem[] = [
  {
    id: 'cw_algo',
    targetSemester: '115-2',
    name: '演算法與資料結構進階',
    credits: 3,
    category: 'required',
    dayOfWeek: 2,
    startTime: '09:10',
    endTime: '12:00',
    classroom: '資工館201',
    instructor: '陳教授',
    colorHex: '#3B82F6',
    emoji: '💻',
    priority: 'must',
    status: 'wishlist',
    notes: '大二必修，第一志願搶課',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'cw_phil',
    targetSemester: '115-2',
    name: '現代哲學與批判思辨',
    credits: 2,
    category: 'general',
    dayOfWeek: 4,
    startTime: '13:20',
    endTime: '15:10',
    classroom: '文學院105',
    instructor: '林教授',
    colorHex: '#10B981',
    emoji: '📖',
    priority: 'high',
    status: 'wishlist',
    notes: '熱門通識人文向度',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'cw_dl',
    targetSemester: '115-2',
    name: '深度學習與神經網路實務',
    credits: 3,
    category: 'elective',
    dayOfWeek: 5,
    startTime: '10:10',
    endTime: '12:00',
    classroom: '電資大樓304',
    instructor: '張教授',
    colorHex: '#8B5CF6',
    emoji: '🤖',
    priority: 'high',
    status: 'wishlist',
    notes: '熱門選修，需自備筆電',
    createdAt: new Date().toISOString(),
  },
];

const DEFAULT_SETTINGS: UserSettings = {
  supabaseUrl: DEFAULT_SUPABASE_URL,
  supabaseAnonKey: DEFAULT_SUPABASE_ANON_KEY,
  shareCode: 'CAMP88',
  ownerName: '我的課表',
  accountingResetDay: 1,
  isIncomeBasedDailyLimit: false,
  customDailyLimit: 300,
  lineUserId: 'U13454cc9b1940c43887043382887308c',
  linePushHour: 7,
  linePushMinute: 0,
  isLinePushEnabled: true,
  lineEveningPushEnabled: true,
  lineEveningPushHour: 18,
  lineEveningPushMinute: 0,
  lineTodoReminderEnabled: true,
  theme: 'light',
  autoSyncEnabled: true,
  autoSyncTime: '23:00',
  autoSyncIntervalMinutes: 240, // 4小時為預設值，兼顧省電與雲端備份
  isShareCourses: true,
  isShareAccounting: true,
  isShareCalendar: true,
  enableFortuneWidget: true,
  pwaNotificationEnabled: true,
  pwaTodoReminderEnabled: true,
  pwaCalendarReminderEnabled: true,
  pwaAccountingReminderEnabled: true,
  pwaPeerRatingReminderEnabled: true,
  pwaSharedCalendarNotifyEnabled: true,
};

interface BudgetInfo {
  todaySpent: number;
  effectiveLimit: number;
  remaining: number;
  daysUntilReset: number;
  totalMonthExpense: number;
}

interface AppContextType {
  activeTab: 'today' | 'schedule' | 'calendar' | 'todos' | 'accounting' | 'settings';
  setActiveTab: (tab: 'today' | 'schedule' | 'calendar' | 'todos' | 'accounting' | 'settings') => void;
  currentUser: UserAccount | null;
  setCurrentUser: (user: UserAccount | null, rememberPassword?: string | null) => void;
  updateCurrentUserDisplayName: (newDisplayName: string) => Promise<boolean>;
  logoutUser: () => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  isLineBotModalOpen: boolean;
  setIsLineBotModalOpen: (open: boolean) => void;
  isShareModalOpen: boolean;
  setIsShareModalOpen: (open: boolean) => void;
  isEventModalOpen: boolean;
  setIsEventModalOpen: (open: boolean) => void;
  isPeriodModalOpen: boolean;
  setIsPeriodModalOpen: (open: boolean) => void;
  // Campus fun features modals
  isFortuneModalOpen: boolean;
  setIsFortuneModalOpen: (open: boolean) => void;
  isFoodRouletteOpen: boolean;
  setIsFoodRouletteOpen: (open: boolean) => void;
  isPomodoroOpen: boolean;
  setIsPomodoroOpen: (open: boolean) => void;
  restoreBackupData: (data: any) => boolean;
  resetAllData: () => void;
  eventToEdit: CalendarEvent | null;
  setEventToEdit: (e: CalendarEvent | null) => void;
  courses: Course[];
  todos: Todo[];
  transactions: Transaction[];
  calendarEvents: CalendarEvent[];
  classPeriods: ClassPeriod[];
  updateClassPeriods: (periods: ClassPeriod[]) => void;
  installments: Installment[];
  addInstallment: (item: Installment) => void;
  updateInstallment: (item: Installment) => void;
  deleteInstallment: (id: string) => void;
  payInstallmentPeriod: (id: string) => Promise<void>;
  recurringItems: RecurringItem[];
  addRecurringItem: (item: RecurringItem) => void;
  updateRecurringItem: (item: RecurringItem) => void;
  deleteRecurringItem: (id: string) => void;
  recordRecurringNow: (id: string) => Promise<void>;
  countdowns: CountdownItem[];
  addCountdown: (item: CountdownItem) => void;
  updateCountdown: (item: CountdownItem) => void;
  deleteCountdown: (id: string) => void;
  togglePinCountdown: (id: string) => void;
  toggleCountdownTodo: (countdownId: string, todoItemId: string) => void;
  addCountdownTodo: (countdownId: string, title: string) => void;
  deleteCountdownTodo: (countdownId: string, todoItemId: string) => void;
  // 🏺 夢想存錢筒 (Savings Jars)
  savingsJars: SavingsJar[];
  addSavingsJar: (jar: SavingsJar) => void;
  updateSavingsJar: (jar: SavingsJar) => void;
  deleteSavingsJar: (id: string) => void;
  depositToSavingsJar: (jarId: string, amount: number, note?: string, syncToExpense?: boolean) => Promise<void>;
  // 🎓 學分進度與成績試算 (GPA & Credit Tracker)
  courseGrades: CourseGradeItem[];
  addCourseGrade: (item: CourseGradeItem) => void;
  updateCourseGrade: (item: CourseGradeItem) => void;
  deleteCourseGrade: (id: string) => void;
  importCoursesToGrades: () => number;
  graduationTarget: GraduationTarget;
  updateGraduationTarget: (target: GraduationTarget) => void;
  // 💰 資產盤點、股票基金與銷帳對帳 (Assets, Stocks & Reconciliation)
  assetAccounts: AssetAccount[];
  addAssetAccount: (account: AssetAccount) => void;
  updateAssetAccount: (account: AssetAccount) => void;
  deleteAssetAccount: (id: string) => void;
  adjustAccountBalance: (accountId: string, newBalance: number, reason: string) => void;
  balanceAdjustments: BalanceAdjustmentRecord[];
  addStockHolding: (accountId: string, stock: StockHoldingItem) => void;
  updateStockHolding: (accountId: string, stock: StockHoldingItem) => void;
  deleteStockHolding: (accountId: string, stockId: string) => void;
  refreshStockPrices: () => Promise<void>;
  survivalSettings: SurvivalBudgetSettings;
  updateSurvivalSettings: (settings: SurvivalBudgetSettings) => void;
  // 🎓 GPA 制度與待選課程心願單 (GPA Scale & Wishlist Courses)
  gpaScale: GpaScale;
  setGpaScale: (scale: GpaScale) => void;
  courseWishlist: CourseWishlistItem[];
  addWishlistCourse: (item: CourseWishlistItem) => void;
  updateWishlistCourse: (item: CourseWishlistItem) => void;
  deleteWishlistCourse: (id: string) => void;
  convertWishlistToCourse: (wishlistId: string) => void;
  splitBills: SplitBill[];
  debts: DebtRecord[];
  addDebt: (debt: DebtRecord) => void;
  updateDebt: (debt: DebtRecord) => void;
  deleteDebt: (id: string) => void;
  repayDebt: (debtId: string, amount: number, note?: string, date?: string) => void;
  addSplitBill: (bill: SplitBill) => void;
  updateSplitBill: (bill: SplitBill) => void;
  deleteSplitBill: (id: string) => void;
  settleSplitParticipant: (billId: string, participantOrIndex: string | number) => void;
  settleEntireSplitBill: (billId: string) => void;
  savedFriends: SavedFriendRecord[];
  settings: UserSettings;
  isSyncing: boolean;
  isOnline: boolean;
  budgetInfo: BudgetInfo;
  catMood: 'happy' | 'sleeping' | 'thinking' | 'proud';
  setCatMood: (mood: 'happy' | 'sleeping' | 'thinking' | 'proud') => void;
  // Custom categories
  customExpenseCategories: CustomCategory[];
  customIncomeCategories: CustomCategory[];
  customTodoCategories: CustomCategory[];
  addCustomCategory: (type: 'expense' | 'income' | 'todo', cat: { name: string; colorHex: string; icon?: string }) => void;
  updateCustomCategory: (type: 'expense' | 'income' | 'todo', id: string, updates: { name?: string; colorHex?: string; icon?: string }) => void;
  reorderCustomCategories: (type: 'expense' | 'income' | 'todo', reordered: CustomCategory[]) => void;
  deleteCustomCategory: (type: 'expense' | 'income' | 'todo', idOrName: string) => void;
  // Scheduled cloud upload & auto-sync
  lastSyncedAt: string | null;
  nextSyncDisplay: string;
  triggerManualUpload: () => Promise<void>;
  addCourse: (course: Course) => Promise<void>;
  updateCourse: (course: Course) => Promise<void>;
  deleteCourse: (id: string) => Promise<void>;
  addTodo: (todo: Todo) => Promise<void>;
  updateTodo: (todo: Todo) => Promise<void>;
  toggleTodo: (id: string) => Promise<void>;
  deleteTodo: (id: string) => Promise<void>;
  addTransaction: (t: Transaction) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;
  addCalendarEvent: (e: CalendarEvent) => Promise<void>;
  updateCalendarEvent: (e: CalendarEvent) => Promise<void>;
  deleteCalendarEvent: (id: string) => Promise<void>;
  saveFriendRecord: (record: SavedFriendRecord) => void;
  removeFriendRecord: (shareCode: string) => void;
  updateSettings: (s: Partial<UserSettings>) => void;
  rateFriendAccounting: (
    friendShareCode: string,
    transactionId: string,
    rating: number,
    feedback: string
  ) => Promise<boolean>;
  syncWithSupabase: (targetUser?: UserAccount | null) => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);


export function deduplicateCourses(list: Course[]): Course[] {
  if (!list || !Array.isArray(list)) return [];
  const result: Course[] = [];
  const seenIds = new Set<string>();
  const seenFingerprints = new Set<string>();

  for (const item of list) {
    if (!item) continue;
    const rawId = String(item.id || '');
    const canonicalId = toUUID(rawId);
    const name = (item.name || '').trim().toLowerCase();
    const fp = `${name}|${item.dayOfWeek}|${item.startTime || ''}`;

    if (
      (rawId && seenIds.has(rawId)) ||
      (canonicalId && seenIds.has(canonicalId)) ||
      (name && seenFingerprints.has(fp))
    ) {
      continue;
    }

    if (rawId) seenIds.add(rawId);
    if (canonicalId) seenIds.add(canonicalId);
    if (name) seenFingerprints.add(fp);
    result.push({ ...item, id: canonicalId });
  }
  return result;
}

export function deduplicateTodos(list: Todo[]): Todo[] {
  if (!list || !Array.isArray(list)) return [];
  const result: Todo[] = [];
  const seenIds = new Set<string>();
  const seenFingerprints = new Set<string>();

  for (const item of list) {
    if (!item) continue;
    const rawId = String(item.id || '');
    const canonicalId = toUUID(rawId);
    const title = (item.title || '').trim().toLowerCase();
    let start = '';
    let due = '';
    if (item.startDate) {
      try { start = new Date(item.startDate).toISOString().slice(0, 10); } catch { start = String(item.startDate).slice(0, 10); }
    }
    if (item.dueDate) {
      try { due = new Date(item.dueDate).toISOString().slice(0, 10); } catch { due = String(item.dueDate).slice(0, 10); }
    }

    const isStarterDemo =
      rawId === 't_travel' ||
      rawId === 't1' ||
      rawId === 't2' ||
      rawId === 't3' ||
      rawId.endsWith('_t_travel') ||
      rawId.endsWith('_t1') ||
      rawId.endsWith('_t2') ||
      rawId.endsWith('_t3') ||
      title.includes('日本東京自由行') ||
      title.includes('演算法作業二') ||
      title.includes('作業系統小考範圍') ||
      title.includes('attention is all you need');

    const fp = isStarterDemo ? `starter_todo|${title}` : `${title}|${start}|${due}`;

    const isDuplicate =
      (rawId && seenIds.has(rawId)) ||
      (canonicalId && seenIds.has(canonicalId)) ||
      (title && seenFingerprints.has(fp));

    if (isDuplicate) {
      if (item.isCompleted) {
        const existing = result.find(
          (r) =>
            r.id === rawId ||
            r.id === canonicalId ||
            toUUID(r.id) === canonicalId ||
            ((r.title || '').trim().toLowerCase() === title)
        );
        if (existing) {
          existing.isCompleted = true;
        }
      }
      continue;
    }

    if (rawId) seenIds.add(rawId);
    if (canonicalId) seenIds.add(canonicalId);
    if (title) seenFingerprints.add(fp);
    result.push({ ...item, id: canonicalId });
  }
  return result;
}

export function deduplicateTransactions(list: Transaction[]): Transaction[] {
  if (!list || !Array.isArray(list)) return [];
  const result: Transaction[] = [];
  const seenIds = new Set<string>();
  const seenFingerprints = new Set<string>();

  for (const item of list) {
    if (!item) continue;
    const rawId = String(item.id || '');
    const canonicalId = toUUID(rawId);
    let normDate = '';
    if (item.date) {
      try {
        normDate = new Date(item.date).toISOString().slice(0, 10);
      } catch {
        normDate = String(item.date).slice(0, 10);
      }
    }
    const amount = Math.round(Number(item.amount) * 100) / 100;
    const notes = (item.notes || '').trim().toLowerCase();
    const cat = (item.categoryName || '').trim().toLowerCase();
    const type = item.type || 'expense';

    // Identify starter dummy transactions to prevent duplicates across date shifts
    const isStarterDemo =
      notes === '學餐排骨飯 + 綠茶' ||
      notes === '捷運通學來回' ||
      rawId === 'tx1' ||
      rawId === 'tx2' ||
      rawId.endsWith('_tx1') ||
      rawId.endsWith('_tx2');

    const fp = isStarterDemo
      ? `starter_tx|${type}|${amount}|${cat}|${notes}`
      : `${type}|${amount}|${normDate}|${cat}|${notes}`;

    const isDuplicate =
      (rawId && seenIds.has(rawId)) ||
      (canonicalId && seenIds.has(canonicalId)) ||
      seenFingerprints.has(fp);

    if (isDuplicate) {
      if (item.peerRating || item.peerFeedback) {
        const existing = result.find(
          (r) =>
            r.id === rawId ||
            r.id === canonicalId ||
            toUUID(r.id) === canonicalId ||
            (isStarterDemo && `${r.type || 'expense'}|${Math.round(Number(r.amount) * 100) / 100}|${(r.categoryName || '').trim().toLowerCase()}|${(r.notes || '').trim().toLowerCase()}` === `${type}|${amount}|${cat}|${notes}`) ||
            `${r.type || 'expense'}|${Math.round(Number(r.amount) * 100) / 100}|${(r.categoryName || '').trim().toLowerCase()}|${(r.notes || '').trim().toLowerCase()}` === `${type}|${amount}|${cat}|${notes}`
        );
        if (existing) {
          if (item.peerRating && !existing.peerRating) existing.peerRating = item.peerRating;
          if (item.peerFeedback && !existing.peerFeedback) existing.peerFeedback = item.peerFeedback;
          if (item.peerRaterName && !existing.peerRaterName) existing.peerRaterName = item.peerRaterName;
        }
      }
      continue;
    }

    if (rawId) seenIds.add(rawId);
    if (canonicalId) seenIds.add(canonicalId);
    seenFingerprints.add(fp);
    result.push({ ...item, id: canonicalId });
  }
  return result;
}

export function deduplicateCalendarEvents(list: CalendarEvent[]): CalendarEvent[] {
  if (!list || !Array.isArray(list)) return [];
  const result: CalendarEvent[] = [];
  const seenIds = new Set<string>();
  const seenFingerprints = new Set<string>();

  for (const item of list) {
    if (!item) continue;
    const rawId = String(item.id || '');
    const canonicalId = toUUID(rawId);
    const title = (item.title || '').trim().toLowerCase();
    let start = '';
    let end = '';
    if (item.startDate) {
      try { start = new Date(item.startDate).toISOString().slice(0, 10); } catch { start = String(item.startDate).slice(0, 10); }
    }
    if (item.endDate) {
      try { end = new Date(item.endDate).toISOString().slice(0, 10); } catch { end = String(item.endDate).slice(0, 10); }
    }

    const isStarterDemo =
      rawId === 'e1' ||
      rawId === 'e2' ||
      rawId === 'e3' ||
      rawId.endsWith('_e1') ||
      rawId.endsWith('_e2') ||
      rawId.endsWith('_e3') ||
      title.includes('期中考週') ||
      title.includes('秋季露營') ||
      title.includes('專題期末成果發表');

    const fp = isStarterDemo ? `starter_event|${title}` : `${title}|${start}|${end}`;

    if (
      (rawId && seenIds.has(rawId)) ||
      (canonicalId && seenIds.has(canonicalId)) ||
      (title && seenFingerprints.has(fp))
    ) {
      continue;
    }

    if (rawId) seenIds.add(rawId);
    if (canonicalId) seenIds.add(canonicalId);
    if (title) seenFingerprints.add(fp);
    result.push({ ...item, id: canonicalId });
  }
  return result;
}

function getScopedKey(userId: string | null | undefined, key: string): string {
  return userId ? `campus_user_${userId}_${key}` : `campus_guest_${key}`;
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<'today' | 'schedule' | 'calendar' | 'todos' | 'accounting' | 'settings'>('today');
  const [isSyncing, setIsSyncing] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [catMood, setCatMood] = useState<'happy' | 'sleeping' | 'thinking' | 'proud'>('happy');

  // 👤 User Account & Modal State
  const initialUser: UserAccount | null = (() => {
    try {
      const saved = localStorage.getItem('campus_auth_session');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  })();

  const [currentUser, setCurrentUserState] = useState<UserAccount | null>(initialUser);
  const activeUserIdRef = useRef<string | null>(initialUser?.id || null);

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isLineBotModalOpen, setIsLineBotModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [isPeriodModalOpen, setIsPeriodModalOpen] = useState(false);
  const [isFortuneModalOpen, setIsFortuneModalOpen] = useState(false);
  const [isFoodRouletteOpen, setIsFoodRouletteOpen] = useState(false);
  const [isPomodoroOpen, setIsPomodoroOpen] = useState(false);
  const [eventToEdit, setEventToEdit] = useState<CalendarEvent | null>(null);

  // Load from LocalStorage (Scoped strictly per user account, with fallback for guest / initial session)
  const [courses, setCourses] = useState<Course[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'courses')) || (!uid ? localStorage.getItem('campus_courses') : null);
    if (saved) {
      try { return deduplicateCourses(JSON.parse(saved)); } catch {}
    }
    return [];
  });

  const [todos, setTodos] = useState<Todo[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'todos')) || (!uid ? localStorage.getItem('campus_todos') : null);
    if (saved) {
      try { return deduplicateTodos(JSON.parse(saved)); } catch {}
    }
    return [];
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'transactions')) || (!uid ? localStorage.getItem('campus_transactions') : null);
    if (saved) {
      try { return deduplicateTransactions(JSON.parse(saved)); } catch {}
    }
    return [];
  });

  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'calendar_events')) || (!uid ? localStorage.getItem('campus_calendar_events') : null);
    if (saved) {
      try { return deduplicateCalendarEvents(JSON.parse(saved)); } catch {}
    }
    return [];
  });

  const coursesRef = useRef(courses);
  coursesRef.current = courses;
  const todosRef = useRef(todos);
  todosRef.current = todos;
  const transactionsRef = useRef(transactions);
  transactionsRef.current = transactions;
  const calendarEventsRef = useRef(calendarEvents);
  calendarEventsRef.current = calendarEvents;
  const isSyncingRef = useRef(false);

  const [classPeriods, setClassPeriods] = useState<ClassPeriod[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'class_periods'));
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    if (!uid) {
      const legacy = localStorage.getItem('campus_class_periods');
      if (legacy) {
        try { return JSON.parse(legacy); } catch {}
      }
    }
    return DEFAULT_CLASS_PERIODS;
  });

  const [savedFriends, setSavedFriends] = useState<SavedFriendRecord[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'saved_friends'));
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    if (!uid) {
      const legacy = localStorage.getItem('campus_saved_friends');
      return legacy ? JSON.parse(legacy) : [];
    }
    return [];
  });

  const savedFriendsRef = useRef(savedFriends);
  savedFriendsRef.current = savedFriends;

  const [installments, setInstallments] = useState<Installment[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'installments')) || (!uid ? localStorage.getItem('campus_installments') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_INSTALLMENTS;
  });

  const [recurringItems, setRecurringItems] = useState<RecurringItem[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'recurring_items')) || (!uid ? localStorage.getItem('campus_recurring_items') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_RECURRING_ITEMS;
  });

  const [countdowns, setCountdowns] = useState<CountdownItem[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'countdowns')) || (!uid ? localStorage.getItem('campus_countdowns') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_COUNTDOWNS;
  });

  const [savingsJars, setSavingsJars] = useState<SavingsJar[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'savings_jars')) || (!uid ? localStorage.getItem('campus_savings_jars') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_SAVINGS_JARS;
  });

  const [courseGrades, setCourseGrades] = useState<CourseGradeItem[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'course_grades')) || (!uid ? localStorage.getItem('campus_course_grades') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_COURSE_GRADES;
  });

  const [graduationTarget, setGraduationTarget] = useState<GraduationTarget>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'graduation_target')) || (!uid ? localStorage.getItem('campus_graduation_target') : null);
    if (saved) {
      try { return { ...DEFAULT_GRADUATION_TARGET, ...JSON.parse(saved) }; } catch {}
    }
    return DEFAULT_GRADUATION_TARGET;
  });

  const [debts, setDebts] = useState<DebtRecord[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'debts')) || (!uid ? localStorage.getItem('campus_debts') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [];
  });

  const [splitBills, setSplitBills] = useState<SplitBill[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'split_bills')) || (!uid ? localStorage.getItem('campus_split_bills') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [];
  });

  // 💰 資產帳戶 (現金、銀行存款、股票基金投資)
  const [assetAccounts, setAssetAccounts] = useState<AssetAccount[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'asset_accounts')) || (!uid ? localStorage.getItem('campus_asset_accounts') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_ASSET_ACCOUNTS;
  });

  // ⚖️ 銷帳與對帳平帳紀錄
  const [balanceAdjustments, setBalanceAdjustments] = useState<BalanceAdjustmentRecord[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'balance_adjustments')) || (!uid ? localStorage.getItem('campus_balance_adjustments') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [];
  });

  // 🐾 月底吃土生存試算設定
  const [survivalSettings, setSurvivalSettings] = useState<SurvivalBudgetSettings>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'survival_settings')) || (!uid ? localStorage.getItem('campus_survival_settings') : null);
    if (saved) {
      try { return { ...DEFAULT_SURVIVAL_SETTINGS, ...JSON.parse(saved) }; } catch {}
    }
    return DEFAULT_SURVIVAL_SETTINGS;
  });

  // 📋 未來排課與待選課程心願單
  const [courseWishlist, setCourseWishlist] = useState<CourseWishlistItem[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'course_wishlist')) || (!uid ? localStorage.getItem('campus_course_wishlist') : null);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_COURSE_WISHLIST;
  });

  // 🎓 GPA 制度 (4.3 vs 4.0)
  const [gpaScale, setGpaScaleState] = useState<GpaScale>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'gpa_scale'));
    return (saved === '4.0' ? '4.0' : '4.3') as GpaScale;
  });

  const setGpaScale = (scale: GpaScale) => {
    setGpaScaleState(scale);
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'gpa_scale'), scale);
  };

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'installments'), JSON.stringify(installments));
  }, [installments]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'recurring_items'), JSON.stringify(recurringItems));
  }, [recurringItems]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'countdowns'), JSON.stringify(countdowns));
  }, [countdowns]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'savings_jars'), JSON.stringify(savingsJars));
  }, [savingsJars]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'course_grades'), JSON.stringify(courseGrades));
  }, [courseGrades]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'graduation_target'), JSON.stringify(graduationTarget));
  }, [graduationTarget]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'debts'), JSON.stringify(debts));
  }, [debts]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'split_bills'), JSON.stringify(splitBills));
  }, [splitBills]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'asset_accounts'), JSON.stringify(assetAccounts));
  }, [assetAccounts]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'balance_adjustments'), JSON.stringify(balanceAdjustments));
  }, [balanceAdjustments]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'survival_settings'), JSON.stringify(survivalSettings));
  }, [survivalSettings]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'course_wishlist'), JSON.stringify(courseWishlist));
  }, [courseWishlist]);

  const [settings, setSettings] = useState<UserSettings>(() => {
    const uid = initialUser?.id;
    let loaded: UserSettings;
    const saved = localStorage.getItem(getScopedKey(uid, 'settings'));
    if (saved) {
      try { loaded = { ...DEFAULT_SETTINGS, ...JSON.parse(saved) }; } catch { loaded = DEFAULT_SETTINGS; }
    } else if (!uid) {
      const legacy = localStorage.getItem('campus_settings');
      loaded = legacy ? { ...DEFAULT_SETTINGS, ...JSON.parse(legacy) } : DEFAULT_SETTINGS;
    } else {
      loaded = {
        ...DEFAULT_SETTINGS,
        ownerName: initialUser?.displayName || (uid ? initialUser!.username : '我的課表'),
        shareCode: initialUser?.shareCode || DEFAULT_SETTINGS.shareCode,
        lineUserId: initialUser?.lineUserId || DEFAULT_SETTINGS.lineUserId,
      };
    }

    // Auto-migrate from old deleted Supabase project dxoobrrjzaovwpyagzgn
    if (loaded.supabaseUrl && (loaded.supabaseUrl.includes('dxoobrrjzaovwpyagzgn') || !loaded.supabaseUrl.startsWith('https://'))) {
      loaded.supabaseUrl = DEFAULT_SUPABASE_URL;
      loaded.supabaseAnonKey = DEFAULT_SUPABASE_ANON_KEY;
      localStorage.removeItem('campus_supabase_url');
      localStorage.removeItem('campus_supabase_anon_key');
    }
    return loaded;
  });

  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  // Custom categories state (scoped per user)
  const [customExpenseCategories, setCustomExpenseCategories] = useState<CustomCategory[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'custom_expense_cats'));
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_EXPENSE_CATEGORIES;
  });

  const [customIncomeCategories, setCustomIncomeCategories] = useState<CustomCategory[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'custom_income_cats'));
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_INCOME_CATEGORIES;
  });

  const [customTodoCategories, setCustomTodoCategories] = useState<CustomCategory[]>(() => {
    const uid = initialUser?.id;
    const saved = localStorage.getItem(getScopedKey(uid, 'custom_todo_cats'));
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return DEFAULT_TODO_CATEGORIES;
  });

  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(() => {
    return localStorage.getItem(getScopedKey(initialUser?.id, 'last_synced_at')) || null;
  });

  // Online / Offline tracking
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Theme effect (light / dark / system)
  useEffect(() => {
    const theme = settings.theme || 'light';
    const root = document.documentElement;
    const applyTheme = (isDark: boolean) => {
      if (isDark) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };

    if (theme === 'dark') {
      applyTheme(true);
    } else if (theme === 'light') {
      applyTheme(false);
    } else {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      applyTheme(mediaQuery.matches);
      const listener = (e: MediaQueryListEvent) => applyTheme(e.matches);
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    }
  }, [settings.theme]);

  // Save to LocalStorage whenever state changes (strictly scoped to active user)
  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'courses'), JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'todos'), JSON.stringify(todos));
  }, [todos]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'transactions'), JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'calendar_events'), JSON.stringify(calendarEvents));
  }, [calendarEvents]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'class_periods'), JSON.stringify(classPeriods));
  }, [classPeriods]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'saved_friends'), JSON.stringify(savedFriends));
  }, [savedFriends]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'settings'), JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'custom_expense_cats'), JSON.stringify(customExpenseCategories));
  }, [customExpenseCategories]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'custom_income_cats'), JSON.stringify(customIncomeCategories));
  }, [customIncomeCategories]);

  useEffect(() => {
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'custom_todo_cats'), JSON.stringify(customTodoCategories));
  }, [customTodoCategories]);

  const updateClassPeriods = (periods: ClassPeriod[]) => {
    setClassPeriods(periods);
    const uid = activeUserIdRef.current;
    localStorage.setItem(getScopedKey(uid, 'class_periods'), JSON.stringify(periods));
    setSettings((prev) => ({ ...prev, classPeriods: periods }));
  };

  const switchUserData = (nextUser: UserAccount | null) => {
    const oldUid = activeUserIdRef.current;
    const newUid = nextUser?.id || null;

    if (oldUid === newUid) return;

    // 1. Flush memory data to old user's storage
    localStorage.setItem(getScopedKey(oldUid, 'courses'), JSON.stringify(courses));
    localStorage.setItem(getScopedKey(oldUid, 'todos'), JSON.stringify(todos));
    localStorage.setItem(getScopedKey(oldUid, 'transactions'), JSON.stringify(transactions));
    localStorage.setItem(getScopedKey(oldUid, 'calendar_events'), JSON.stringify(calendarEvents));
    localStorage.setItem(getScopedKey(oldUid, 'class_periods'), JSON.stringify(classPeriods));
    localStorage.setItem(getScopedKey(oldUid, 'saved_friends'), JSON.stringify(savedFriends));
    localStorage.setItem(getScopedKey(oldUid, 'settings'), JSON.stringify(settings));
    localStorage.setItem(getScopedKey(oldUid, 'custom_expense_cats'), JSON.stringify(customExpenseCategories));
    localStorage.setItem(getScopedKey(oldUid, 'custom_income_cats'), JSON.stringify(customIncomeCategories));
    localStorage.setItem(getScopedKey(oldUid, 'custom_todo_cats'), JSON.stringify(customTodoCategories));
    localStorage.setItem(getScopedKey(oldUid, 'debts'), JSON.stringify(debts));
    localStorage.setItem(getScopedKey(oldUid, 'split_bills'), JSON.stringify(splitBills));
    localStorage.setItem(getScopedKey(oldUid, 'installments'), JSON.stringify(installments));
    localStorage.setItem(getScopedKey(oldUid, 'recurring_items'), JSON.stringify(recurringItems));
    localStorage.setItem(getScopedKey(oldUid, 'countdowns'), JSON.stringify(countdowns));
    localStorage.setItem(getScopedKey(oldUid, 'asset_accounts'), JSON.stringify(assetAccounts));
    localStorage.setItem(getScopedKey(oldUid, 'balance_adjustments'), JSON.stringify(balanceAdjustments));
    localStorage.setItem(getScopedKey(oldUid, 'survival_settings'), JSON.stringify(survivalSettings));
    localStorage.setItem(getScopedKey(oldUid, 'course_wishlist'), JSON.stringify(courseWishlist));

    // 2. Switch active ref
    activeUserIdRef.current = newUid;

    // 3. Load next user's data from their scoped storage (cloud sync will fetch and merge latest real data)
    const rawCourses = localStorage.getItem(getScopedKey(newUid, 'courses'));
    if (rawCourses) {
      setCourses(deduplicateCourses(JSON.parse(rawCourses)));
    } else {
      setCourses([]);
    }

    const rawTodos = localStorage.getItem(getScopedKey(newUid, 'todos'));
    if (rawTodos) {
      setTodos(deduplicateTodos(JSON.parse(rawTodos)));
    } else {
      setTodos([]);
    }

    const rawTx = localStorage.getItem(getScopedKey(newUid, 'transactions'));
    if (rawTx) {
      setTransactions(deduplicateTransactions(JSON.parse(rawTx)));
    } else {
      setTransactions([]);
    }

    const rawEvents = localStorage.getItem(getScopedKey(newUid, 'calendar_events'));
    if (rawEvents) {
      setCalendarEvents(deduplicateCalendarEvents(JSON.parse(rawEvents)));
    } else {
      setCalendarEvents([]);
    }

    const rawPeriods = localStorage.getItem(getScopedKey(newUid, 'class_periods'));
    setClassPeriods(rawPeriods ? JSON.parse(rawPeriods) : DEFAULT_CLASS_PERIODS);

    const rawFriends = localStorage.getItem(getScopedKey(newUid, 'saved_friends'));
    setSavedFriends(rawFriends ? JSON.parse(rawFriends) : []);

    const rawSettings = localStorage.getItem(getScopedKey(newUid, 'settings'));
    if (rawSettings) {
      setSettings(JSON.parse(rawSettings));
    } else {
      setSettings({
        ...DEFAULT_SETTINGS,
        ownerName: nextUser?.displayName || (newUid ? nextUser!.username : '我的課表'),
        shareCode: nextUser?.shareCode || DEFAULT_SETTINGS.shareCode,
        lineUserId: nextUser?.lineUserId || DEFAULT_SETTINGS.lineUserId,
      });
    }

    const rawExpCats = localStorage.getItem(getScopedKey(newUid, 'custom_expense_cats'));
    setCustomExpenseCategories(rawExpCats ? JSON.parse(rawExpCats) : DEFAULT_EXPENSE_CATEGORIES);

    const rawIncCats = localStorage.getItem(getScopedKey(newUid, 'custom_income_cats'));
    setCustomIncomeCategories(rawIncCats ? JSON.parse(rawIncCats) : DEFAULT_INCOME_CATEGORIES);

    const rawTodoCats = localStorage.getItem(getScopedKey(newUid, 'custom_todo_cats'));
    setCustomTodoCategories(rawTodoCats ? JSON.parse(rawTodoCats) : DEFAULT_TODO_CATEGORIES);

    const rawDebts = localStorage.getItem(getScopedKey(newUid, 'debts'));
    setDebts(rawDebts ? JSON.parse(rawDebts) : []);

    const rawSplitBills = localStorage.getItem(getScopedKey(newUid, 'split_bills'));
    setSplitBills(rawSplitBills ? JSON.parse(rawSplitBills) : []);

    const rawInsts = localStorage.getItem(getScopedKey(newUid, 'installments'));
    setInstallments(rawInsts ? JSON.parse(rawInsts) : DEFAULT_INSTALLMENTS);

    const rawRecs = localStorage.getItem(getScopedKey(newUid, 'recurring_items'));
    setRecurringItems(rawRecs ? JSON.parse(rawRecs) : DEFAULT_RECURRING_ITEMS);

    const rawCds = localStorage.getItem(getScopedKey(newUid, 'countdowns'));
    setCountdowns(rawCds ? JSON.parse(rawCds) : DEFAULT_COUNTDOWNS);

    const rawAssets = localStorage.getItem(getScopedKey(newUid, 'asset_accounts'));
    setAssetAccounts(rawAssets ? JSON.parse(rawAssets) : DEFAULT_ASSET_ACCOUNTS);

    const rawAdj = localStorage.getItem(getScopedKey(newUid, 'balance_adjustments'));
    setBalanceAdjustments(rawAdj ? JSON.parse(rawAdj) : []);

    const rawSurv = localStorage.getItem(getScopedKey(newUid, 'survival_settings'));
    setSurvivalSettings(rawSurv ? JSON.parse(rawSurv) : DEFAULT_SURVIVAL_SETTINGS);

    const rawWish = localStorage.getItem(getScopedKey(newUid, 'course_wishlist'));
    setCourseWishlist(rawWish ? JSON.parse(rawWish) : DEFAULT_COURSE_WISHLIST);

    const rawGpa = localStorage.getItem(getScopedKey(newUid, 'gpa_scale'));
    setGpaScaleState((rawGpa === '4.0' ? '4.0' : '4.3') as GpaScale);

    const rawSynced = localStorage.getItem(getScopedKey(newUid, 'last_synced_at'));
    setLastSyncedAt(rawSynced || null);
  };

  // Local-first cloud sync (以本機資料為準同步至雲端，避免清空本機資料)
  const syncWithSupabase = async (targetUser?: UserAccount | null) => {
    if (!navigator.onLine || isSyncingRef.current) return;
    isSyncingRef.current = true;
    setIsSyncing(true);
    const activeUser = targetUser !== undefined ? targetUser : currentUser;
    const userKey = activeUser ? activeUser.id : (currentUser?.id || 'guest');
    const currentSettings = settingsRef.current;

    try {
      // 1. 本機資料優先：先將手機上的所有課程、待辦、收支、行事曆推送到 Supabase
      const currentLocalData = {
        courses: deduplicateCourses(coursesRef.current),
        todos: deduplicateTodos(todosRef.current),
        transactions: deduplicateTransactions(transactionsRef.current),
        calendarEvents: deduplicateCalendarEvents(calendarEventsRef.current),
      };

      await syncAllLocalDataToSupabase(userKey, currentLocalData);

      // 同步更新好友分享排程與推播設定
      if (currentSettings.shareCode) {
        publishSharedSchedule({
          shareCode: currentSettings.shareCode,
          ownerName: currentSettings.ownerName || '我的課表',
          isSharingEnabled: true,
          coursesData: currentLocalData.courses,
          todosData: currentLocalData.todos,
          accountingData: currentLocalData.transactions,
          calendarEventsData: currentLocalData.calendarEvents,
          isExpenseSharingEnabled: true,
        }).catch(() => {});

        saveUserLineBotPushSettings(
          userKey,
          currentSettings.lineUserId || '',
          currentSettings.shareCode,
          currentSettings.ownerName || '我的課表',
          currentSettings.linePushHour ?? 7,
          currentSettings.linePushMinute ?? 0,
          currentSettings.isLinePushEnabled ?? true,
          currentLocalData.courses,
          currentLocalData.todos,
          currentSettings.lineEveningPushEnabled ?? true,
          currentSettings.lineEveningPushHour ?? 18,
          currentSettings.lineEveningPushMinute ?? 0,
          currentLocalData.transactions,
          currentSettings.lineTodoReminderEnabled ?? true
        ).catch(() => {});
      }

      // 2. 擷取雲端最新資料（透過智慧指紋去重合併補齊，絕不產生雙份重複紀錄）
      const [cloudCourses, cloudTodos, cloudTx, cloudEvents] = await Promise.all([
        fetchCoursesFromSupabase(userKey),
        fetchTodosFromSupabase(userKey),
        fetchTransactionsFromSupabase(userKey),
        fetchCalendarEventsFromSupabase(userKey),
      ]);

      // Guard: 確保在異步請求期間使用者帳號未切換
      if ((activeUser?.id || null) === activeUserIdRef.current) {
        if (cloudCourses.length > 0) {
          setCourses((prev) => deduplicateCourses([...prev, ...cloudCourses]));
        }
        if (cloudTodos.length > 0) {
          setTodos((prev) => deduplicateTodos([...prev, ...cloudTodos]));
        }
        if (cloudTx.length > 0) {
          setTransactions((prev) => deduplicateTransactions([...prev, ...cloudTx]));
        }
        if (cloudEvents.length > 0) {
          setCalendarEvents((prev) => deduplicateCalendarEvents([...prev, ...cloudEvents]));
        }
      }

      const nowIso = new Date().toISOString();
      setLastSyncedAt(nowIso);
      localStorage.setItem(getScopedKey(userKey, 'last_synced_at'), nowIso);
    } catch (e) {
      console.warn('Cloud sync error:', e);
    } finally {
      isSyncingRef.current = false;
      setIsSyncing(false);
    }
  };

  const syncWithSupabaseRef = useRef(syncWithSupabase);
  syncWithSupabaseRef.current = syncWithSupabase;

  const triggerManualUpload = async () => {
    await syncWithSupabase();
  };

  // Scheduled cloud upload & auto-sync timer
  const nextSyncDisplay = useMemo(() => {
    if (!settings.autoSyncEnabled) return '已停用定時上傳';
    const intervalMins = settings.autoSyncIntervalMinutes ?? 240;
    if (intervalMins === 0) {
      return settings.autoSyncTime ? `每日 ${settings.autoSyncTime} 上傳` : '僅手動同步';
    }
    if (intervalMins >= 60) {
      const hours = Math.round(intervalMins / 60);
      return `每 ${hours} 小時自動同步`;
    }
    return `每 ${intervalMins} 分鐘自動同步`;
  }, [settings.autoSyncEnabled, settings.autoSyncTime, settings.autoSyncIntervalMinutes]);

  useEffect(() => {
    if (!settings.autoSyncEnabled) return;

    let lastTriggeredMinute = '';

    const intervalTimer = setInterval(() => {
      const now = new Date();
      const currentHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

      // Check periodic interval (e.g. 240 mins = 4 hours, 480 mins = 8 hours)
      if (settings.autoSyncIntervalMinutes && settings.autoSyncIntervalMinutes > 0) {
        if (lastSyncedAt) {
          const lastTime = new Date(lastSyncedAt).getTime();
          const diffMins = (now.getTime() - lastTime) / (1000 * 60);
          if (diffMins >= settings.autoSyncIntervalMinutes) {
            syncWithSupabase();
            return;
          }
        }
      } else if (settings.autoSyncTime && currentHHMM === settings.autoSyncTime && lastTriggeredMinute !== currentHHMM) {
        // If interval is 0, only sync at fixed time (e.g. 23:00)
        lastTriggeredMinute = currentHHMM;
        syncWithSupabase();
        return;
      }
    }, 30000);

    return () => clearInterval(intervalTimer);
  }, [settings.autoSyncEnabled, settings.autoSyncTime, settings.autoSyncIntervalMinutes, lastSyncedAt]);

  // 🔔 啟動 PWA 系統推播通知背景輪詢排程 (行事曆、待辦即期、記帳打卡、好友評分)
  useEffect(() => {
    const stopScheduler = startPwaNotificationScheduler(() => ({
      todos: todosRef.current,
      calendarEvents: calendarEventsRef.current,
      transactions: transactionsRef.current,
      savedFriends: savedFriendsRef.current,
      isTodoReminderEnabled: settingsRef.current.pwaTodoReminderEnabled ?? true,
      isCalendarReminderEnabled: settingsRef.current.pwaCalendarReminderEnabled ?? true,
      isAccountingReminderEnabled: settingsRef.current.pwaAccountingReminderEnabled ?? true,
      isFriendRatingReminderEnabled: settingsRef.current.pwaPeerRatingReminderEnabled ?? true,
    }));

    return () => {
      stopScheduler();
    };
  }, []);

  // 🤝 週期性自動同步好友共享行事曆 (每 3 分鐘檢查是否有新增或刪除行程/待辦)
  useEffect(() => {
    if (!isOnline || savedFriends.length === 0) return;
    const interval = setInterval(async () => {
      for (const friend of savedFriendsRef.current) {
        try {
          const latest = await fetchSharedScheduleByCode(friend.shareCode);
          if (latest) {
            saveFriendRecord({
              ...friend,
              cachedSchedule: latest,
              lastViewedAt: new Date().toISOString(),
            });
          }
        } catch {
          // ignore background sync errors
        }
      }
    }, 3 * 60 * 1000);

    return () => clearInterval(interval);
  }, [isOnline, savedFriends.length]);

  const updateCurrentUserDisplayName = async (newDisplayName: string): Promise<boolean> => {
    const cleanName = newDisplayName.trim() || '同學';
    if (currentUser) {
      const updatedUser: UserAccount = { ...currentUser, displayName: cleanName };
      setCurrentUserState(updatedUser);
      localStorage.setItem('campus_auth_session', JSON.stringify(updatedUser));
      await updateUserAccountDisplayName(currentUser.id, cleanName);
    }
    setSettings((prev) => ({ ...prev, ownerName: cleanName }));
    const key = getScopedKey(currentUser?.id, 'settings');
    const updatedSettings = { ...settings, ownerName: cleanName };
    localStorage.setItem(key, JSON.stringify(updatedSettings));
    return true;
  };

  const setCurrentUser = (user: UserAccount | null, rememberPassword?: string | null) => {
    switchUserData(user);
    setCurrentUserState(user);
    if (user) {
      localStorage.setItem('campus_auth_session', JSON.stringify(user));
      if (rememberPassword !== undefined) {
        if (rememberPassword) {
          localStorage.setItem('campus_auth_cred', JSON.stringify({ u: user.username, p: rememberPassword }));
        } else {
          localStorage.removeItem('campus_auth_cred');
        }
      }
      setSettings((prev) => ({
        ...prev,
        shareCode: user.shareCode || prev.shareCode,
        ownerName: user.displayName || prev.ownerName,
        lineUserId: user.lineUserId || prev.lineUserId,
      }));
      syncWithSupabase(user);
    } else {
      localStorage.removeItem('campus_auth_session');
      localStorage.removeItem('campus_auth_cred');
      syncWithSupabase(null);
    }
  };

  const logoutUser = () => {
    const oldUid = activeUserIdRef.current;
    if (oldUid) {
      localStorage.setItem(getScopedKey(oldUid, 'courses'), JSON.stringify(courses));
      localStorage.setItem(getScopedKey(oldUid, 'todos'), JSON.stringify(todos));
      localStorage.setItem(getScopedKey(oldUid, 'transactions'), JSON.stringify(transactions));
      localStorage.setItem(getScopedKey(oldUid, 'calendar_events'), JSON.stringify(calendarEvents));
    }
    localStorage.removeItem('campus_auth_session');
    localStorage.removeItem('campus_auth_cred');
    activeUserIdRef.current = null;
    setCurrentUserState(null);
    setCourses([]);
    setTodos([]);
    setTransactions([]);
    setCalendarEvents([]);
  };

  // 1. 每打開 PWA (初次啟動 / Cold Start) 自動登入並同步上傳本機資料至雲端
  useEffect(() => {
    let isMounted = true;
    const attemptAutoLoginAndSync = async () => {
      try {
        const savedCred = localStorage.getItem('campus_auth_cred');
        if (savedCred && !currentUser) {
          const { u, p } = JSON.parse(savedCred);
          if (u && p) {
            const res = await loginUserAccount(u, p);
            if (res.ok && res.user && isMounted) {
              switchUserData(res.user);
              setCurrentUserState(res.user);
              localStorage.setItem('campus_auth_session', JSON.stringify(res.user));
              await syncWithSupabase(res.user);
              return;
            }
          }
        }
      } catch (err) {
        console.warn('Auto login startup exception:', err);
      }
      if (isMounted) {
        await syncWithSupabase();
      }
    };

    attemptAutoLoginAndSync();
    return () => {
      isMounted = false;
    };
  }, []);

  // 2. 每次打開 / 返回 PWA (從背景喚醒、iPhone/Android 切換回 APP、分頁可見) 自動上傳同步至雲端
  useEffect(() => {
    let lastResumeSyncTime = Date.now();

    const handleAppOpenOrResume = () => {
      if (document.visibilityState === 'visible' && navigator.onLine) {
        const now = Date.now();
        // 節流保護：至少間隔 15 秒才重複觸發喚醒同步，避免頻繁切換分頁重複洗板
        if (now - lastResumeSyncTime > 15000) {
          lastResumeSyncTime = now;
          syncWithSupabaseRef.current();
        }
      }
    };

    document.addEventListener('visibilitychange', handleAppOpenOrResume);
    window.addEventListener('pageshow', handleAppOpenOrResume);
    window.addEventListener('focus', handleAppOpenOrResume);

    return () => {
      document.removeEventListener('visibilitychange', handleAppOpenOrResume);
      window.removeEventListener('pageshow', handleAppOpenOrResume);
      window.removeEventListener('focus', handleAppOpenOrResume);
    };
  }, []);

  // Budget calculation
  const budgetInfo: BudgetInfo = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);

    // 今日花費
    const todaySpent = transactions
      .filter((t) => t.type === 'expense' && t.date.slice(0, 10) === todayStr)
      .reduce((acc, cur) => acc + cur.amount, 0);

    // 本月總支出
    const totalMonthExpense = transactions
      .filter((t) => t.type === 'expense')
      .reduce((acc, cur) => acc + cur.amount, 0);

    // 計算重置日倒數
    const resetDay = settings.accountingResetDay || 1;
    let nextReset = new Date(now.getFullYear(), now.getMonth(), resetDay);
    if (now.getDate() >= resetDay) {
      nextReset = new Date(now.getFullYear(), now.getMonth() + 1, resetDay);
    }
    const daysUntilReset = Math.max(1, Math.ceil((nextReset.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

    const effectiveLimit = settings.customDailyLimit || 300;
    const remaining = effectiveLimit - todaySpent;

    return {
      todaySpent,
      effectiveLimit,
      remaining,
      daysUntilReset,
      totalMonthExpense,
    };
  }, [transactions, settings]);

  // Custom Category Methods
  const addCustomCategory = (
    type: 'expense' | 'income' | 'todo',
    cat: { name: string; colorHex: string; icon?: string }
  ) => {
    const newCat: CustomCategory = {
      id: `cat_${Date.now()}`,
      name: cat.name.trim(),
      colorHex: cat.colorHex,
      icon: cat.icon || 'tag',
    };
    if (type === 'expense') {
      setCustomExpenseCategories((prev) =>
        prev.some((c) => c.name === newCat.name) ? prev : [...prev, newCat]
      );
    } else if (type === 'income') {
      setCustomIncomeCategories((prev) =>
        prev.some((c) => c.name === newCat.name) ? prev : [...prev, newCat]
      );
    } else {
      setCustomTodoCategories((prev) =>
        prev.some((c) => c.name === newCat.name) ? prev : [...prev, newCat]
      );
    }
  };

  const deleteCustomCategory = (
    type: 'expense' | 'income' | 'todo',
    idOrName: string
  ) => {
    if (type === 'expense') {
      setCustomExpenseCategories((prev) =>
        prev.filter((c) => c.id !== idOrName && c.name !== idOrName)
      );
    } else if (type === 'income') {
      setCustomIncomeCategories((prev) =>
        prev.filter((c) => c.id !== idOrName && c.name !== idOrName)
      );
    } else {
      setCustomTodoCategories((prev) =>
        prev.filter((c) => c.id !== idOrName && c.name !== idOrName)
      );
    }
  };

  const updateCustomCategory = (
    type: 'expense' | 'income' | 'todo',
    id: string,
    updates: { name?: string; colorHex?: string; icon?: string }
  ) => {
    const updater = (prev: CustomCategory[]) =>
      prev.map((c) => (c.id === id ? { ...c, ...updates } : c));
    if (type === 'expense') setCustomExpenseCategories(updater);
    else if (type === 'income') setCustomIncomeCategories(updater);
    else setCustomTodoCategories(updater);
  };

  const reorderCustomCategories = (
    type: 'expense' | 'income' | 'todo',
    reordered: CustomCategory[]
  ) => {
    if (type === 'expense') setCustomExpenseCategories(reordered);
    else if (type === 'income') setCustomIncomeCategories(reordered);
    else setCustomTodoCategories(reordered);
  };

  // Actions
  const addCourse = async (course: Course) => {
    const canonicalId = toUUID(course.id || `course_${Date.now()}_${Math.random()}`);
    const enriched: Course = { ...course, id: canonicalId, userId: currentUser?.id || course.userId };
    setCourses((prev) => {
      const next = deduplicateCourses([...prev, enriched]);
      coursesRef.current = next;
      syncScheduleToCloud(next, todosRef.current, transactionsRef.current, calendarEventsRef.current);
      return next;
    });
    await upsertCourseToSupabase(enriched, currentUser?.id);
    setCatMood('happy');
  };

  const updateCourse = async (course: Course) => {
    const canonicalId = toUUID(course.id);
    const enriched: Course = { ...course, id: canonicalId, userId: currentUser?.id || course.userId };
    setCourses((prev) => {
      const next = prev.map((c) => (toUUID(c.id) === canonicalId ? enriched : c));
      coursesRef.current = next;
      syncScheduleToCloud(next, todosRef.current, transactionsRef.current, calendarEventsRef.current);
      return next;
    });
    await upsertCourseToSupabase(enriched, currentUser?.id);
  };

  const deleteCourse = async (id: string) => {
    const canonicalId = toUUID(id);
    setCourses((prev) => {
      const next = prev.filter((c) => toUUID(c.id) !== canonicalId);
      coursesRef.current = next;
      syncScheduleToCloud(next, todosRef.current, transactionsRef.current, calendarEventsRef.current);
      return next;
    });
    await deleteCourseFromSupabase(id);
  };

  // Real-time synchronization helper to publish shared schedule
  const syncScheduleToCloud = (
    cList = coursesRef.current,
    tList = todosRef.current,
    txList = transactionsRef.current,
    evList = calendarEventsRef.current
  ) => {
    const sCode = currentUser?.shareCode || settingsRef.current.shareCode;
    if (!sCode) return;
    publishSharedSchedule({
      shareCode: sCode,
      ownerName: currentUser?.displayName || settingsRef.current.ownerName || '同學',
      isSharingEnabled: true,
      coursesData: cList,
      todosData: tList,
      accountingData: txList,
      calendarEventsData: evList,
      isExpenseSharingEnabled: true,
    }).catch(() => {});
  };

  const addTodo = async (todo: Todo) => {
    const canonicalId = toUUID(todo.id || `todo_${Date.now()}_${Math.random()}`);
    const enriched: Todo = { ...todo, id: canonicalId, userId: currentUser?.id || todo.userId };
    setTodos((prev) => {
      const next = deduplicateTodos([enriched, ...prev]);
      todosRef.current = next;
      syncScheduleToCloud(coursesRef.current, next, transactionsRef.current, calendarEventsRef.current);
      return next;
    });
    // ⏳ 連動建立重要日子倒數
    if (enriched.isCountdown && enriched.dueDate) {
      const targetDate = enriched.dueDate.slice(0, 10);
      const newCd: CountdownItem = {
        id: toUUID(`cd_todo_${canonicalId}`),
        userId: currentUser?.id,
        title: enriched.title,
        targetDate,
        mode: 'countdown',
        emoji: '📝',
        category: 'exam',
        colorHex: enriched.colorHex || '#F59E0B',
        isPinned: false,
        notes: enriched.notes,
        linkedTodoId: canonicalId,
      };
      setCountdowns((prev) => [newCd, ...prev.filter((c) => c.linkedTodoId !== canonicalId)]);
    }
    await upsertTodoToSupabase(enriched, currentUser?.id);
    setCatMood('thinking');
  };

  const updateTodo = async (todo: Todo) => {
    const canonicalId = toUUID(todo.id);
    const enriched: Todo = { ...todo, id: canonicalId, userId: currentUser?.id || todo.userId };
    setTodos((prev) => {
      const next = prev.map((t) => (toUUID(t.id) === canonicalId ? enriched : t));
      todosRef.current = next;
      syncScheduleToCloud(coursesRef.current, next, transactionsRef.current, calendarEventsRef.current);
      return next;
    });
    // ⏳ 連動更新/移除重要日子倒數
    if (enriched.isCountdown && enriched.dueDate) {
      const targetDate = enriched.dueDate.slice(0, 10);
      setCountdowns((prev) => {
        const exists = prev.some((c) => c.linkedTodoId === canonicalId);
        if (exists) {
          return prev.map((c) =>
            c.linkedTodoId === canonicalId
              ? { ...c, title: enriched.title, targetDate, notes: enriched.notes }
              : c
          );
        } else {
          const newCd: CountdownItem = {
            id: toUUID(`cd_todo_${canonicalId}`),
            userId: currentUser?.id,
            title: enriched.title,
            targetDate,
            mode: 'countdown',
            emoji: '📝',
            category: 'exam',
            colorHex: enriched.colorHex || '#F59E0B',
            isPinned: false,
            notes: enriched.notes,
            linkedTodoId: canonicalId,
          };
          return [newCd, ...prev];
        }
      });
    } else if (!enriched.isCountdown) {
      setCountdowns((prev) => prev.filter((c) => c.linkedTodoId !== canonicalId));
    }
    await upsertTodoToSupabase(enriched, currentUser?.id);
  };

  const toggleTodo = async (id: string) => {
    const canonicalId = toUUID(id);
    setTodos((prev) => {
      const next = prev.map((t) => {
        if (toUUID(t.id) === canonicalId) {
          const updated: Todo = { ...t, isCompleted: !t.isCompleted, userId: currentUser?.id || t.userId };
          upsertTodoToSupabase(updated, currentUser?.id);
          if (updated.isCompleted) setCatMood('proud');
          return updated;
        }
        return t;
      });
      todosRef.current = next;
      syncScheduleToCloud(coursesRef.current, next, transactionsRef.current, calendarEventsRef.current);
      return next;
    });
  };

  const deleteTodo = async (id: string) => {
    const canonicalId = toUUID(id);
    setTodos((prev) => {
      const next = prev.filter((t) => toUUID(t.id) !== canonicalId);
      todosRef.current = next;
      syncScheduleToCloud(coursesRef.current, next, transactionsRef.current, calendarEventsRef.current);
      return next;
    });
    // ⏳ 連動刪除重要日子倒數
    setCountdowns((prev) => prev.filter((c) => c.linkedTodoId !== canonicalId));
    await deleteTodoFromSupabase(id);
  };

  const addTransaction = async (t: Transaction) => {
    const canonicalId = toUUID(t.id || `tx_${Date.now()}_${Math.random()}`);
    const enriched: Transaction = { ...t, id: canonicalId, userId: currentUser?.id || t.userId };
    setTransactions((prev) => {
      const next = deduplicateTransactions([enriched, ...prev]);
      transactionsRef.current = next;
      // Real-time publish to shared_schedules for friends
      syncScheduleToCloud(coursesRef.current, todosRef.current, next, calendarEventsRef.current);
      return next;
    });

    // 💰 連動資產帳戶餘額 (Asset Account Balance Linkage)
    setAssetAccounts((prev) => {
      const pm = (t.paymentMethodName || '').toLowerCase();
      const isCash = pm.includes('現') || pm.includes('cash');
      const targetType = isCash ? 'cash' : 'bank';
      const delta = t.type === 'expense' ? -t.amount : t.amount;

      let matchedIndex = prev.findIndex((acc) => pm.includes(acc.name.toLowerCase()));
      if (matchedIndex === -1) {
        matchedIndex = prev.findIndex((acc) => acc.type === targetType);
      }
      if (matchedIndex === -1 && prev.length > 0) {
        matchedIndex = 0;
      }
      if (matchedIndex !== -1) {
        return prev.map((acc, idx) =>
          idx === matchedIndex
            ? { ...acc, balance: Math.round((acc.balance + delta) * 10) / 10, updatedAt: new Date().toISOString() }
            : acc
        );
      }
      return prev;
    });

    await upsertTransactionToSupabase(enriched, currentUser?.id);
    setCatMood('happy');
  };

  const deleteTransaction = async (id: string) => {
    const canonicalId = toUUID(id);
    const targetTx = transactions.find((t) => toUUID(t.id) === canonicalId);
    if (targetTx) {
      setAssetAccounts((prev) => {
        const pm = (targetTx.paymentMethodName || '').toLowerCase();
        const isCash = pm.includes('現') || pm.includes('cash');
        const targetType = isCash ? 'cash' : 'bank';
        const reverseDelta = targetTx.type === 'expense' ? targetTx.amount : -targetTx.amount;

        let matchedIndex = prev.findIndex((acc) => pm.includes(acc.name.toLowerCase()));
        if (matchedIndex === -1) matchedIndex = prev.findIndex((acc) => acc.type === targetType);
        if (matchedIndex === -1 && prev.length > 0) matchedIndex = 0;

        if (matchedIndex !== -1) {
          return prev.map((acc, idx) =>
            idx === matchedIndex
              ? { ...acc, balance: Math.round((acc.balance + reverseDelta) * 10) / 10, updatedAt: new Date().toISOString() }
              : acc
          );
        }
        return prev;
      });
    }

    setTransactions((prev) => {
      const next = prev.filter((t) => toUUID(t.id) !== canonicalId);
      transactionsRef.current = next;
      syncScheduleToCloud(coursesRef.current, todosRef.current, next, calendarEventsRef.current);
      return next;
    });
    await deleteTransactionFromSupabase(id);
  };

  const rateFriendAccounting = async (
    friendShareCode: string,
    transactionId: string,
    rating: number,
    feedback: string
  ): Promise<boolean> => {
    const raterName = currentUser?.displayName || settings.ownerName || '好友';
    const ok = await rateFriendTransaction(friendShareCode, transactionId, rating, feedback, raterName);
    if (ok) {
      // Update local cached friend record immediately
      setSavedFriends((prev) =>
        prev.map((f) => {
          if (f.shareCode.toUpperCase() === friendShareCode.toUpperCase() && f.cachedSchedule) {
            const currentList = Array.isArray(f.cachedSchedule.accountingData)
              ? f.cachedSchedule.accountingData
              : [];
            const targetUuid = toUUID(transactionId);
            const updatedTxList = currentList.map((tx) => {
              if (tx.id === transactionId || toUUID(tx.id) === targetUuid) {
                return {
                  ...tx,
                  peerRating: rating,
                  peerFeedback: feedback,
                  peerRaterName: raterName,
                  ratedAt: new Date().toISOString(),
                };
              }
              return tx;
            });
            return {
              ...f,
              cachedSchedule: {
                ...f.cachedSchedule,
                accountingData: updatedTxList,
              },
            };
          }
          return f;
        })
      );
    }
    return ok;
  };

  const addCalendarEvent = async (e: CalendarEvent) => {
    const canonicalId = toUUID(e.id || `event_${Date.now()}_${Math.random()}`);
    const enriched: CalendarEvent = { ...e, id: canonicalId, userId: currentUser?.id || e.userId };
    setCalendarEvents((prev) => {
      const next = deduplicateCalendarEvents([...prev, enriched]);
      calendarEventsRef.current = next;
      syncScheduleToCloud(coursesRef.current, todosRef.current, transactionsRef.current, next);
      return next;
    });
    await upsertCalendarEventToSupabase(enriched, currentUser?.id);
    setCatMood('happy');
  };

  const updateCalendarEvent = async (e: CalendarEvent) => {
    const canonicalId = toUUID(e.id);
    const enriched: CalendarEvent = { ...e, id: canonicalId, userId: currentUser?.id || e.userId };
    setCalendarEvents((prev) => {
      const next = prev.map((item) => (toUUID(item.id) === canonicalId ? enriched : item));
      calendarEventsRef.current = next;
      syncScheduleToCloud(coursesRef.current, todosRef.current, transactionsRef.current, next);
      return next;
    });
    await upsertCalendarEventToSupabase(enriched, currentUser?.id);
  };

  const deleteCalendarEvent = async (id: string) => {
    const canonicalId = toUUID(id);
    setCalendarEvents((prev) => {
      const next = prev.filter((item) => toUUID(item.id) !== canonicalId);
      calendarEventsRef.current = next;
      syncScheduleToCloud(coursesRef.current, todosRef.current, transactionsRef.current, next);
      return next;
    });
    await deleteCalendarEventFromSupabase(id);
  };

  // --------------------------------------------------------------------------
  // 🤝 往來債務 (Debts, Loans & Installments)
  // --------------------------------------------------------------------------
  const addDebt = (debt: DebtRecord) => {
    const canonicalId = toUUID(debt.id || `debt_${Date.now()}_${Math.random()}`);
    const newDebt: DebtRecord = {
      ...debt,
      id: canonicalId,
      userId: currentUser?.id || debt.userId,
      remainingAmount: debt.remainingAmount !== undefined ? debt.remainingAmount : debt.totalAmount,
      isSettled: (debt.remainingAmount !== undefined ? debt.remainingAmount : debt.totalAmount) <= 0,
      repayments: debt.repayments || [],
      createdAt: debt.createdAt || new Date().toISOString(),
    };
    setDebts((prev) => [newDebt, ...prev]);
    setCatMood('happy');
  };

  const updateDebt = (debt: DebtRecord) => {
    setDebts((prev) => prev.map((d) => (d.id === debt.id ? debt : d)));
  };

  const deleteDebt = (id: string) => {
    setDebts((prev) => prev.filter((d) => d.id !== id));
  };

  const repayDebt = (debtId: string, amount: number, note?: string, date?: string) => {
    setDebts((prev) =>
      prev.map((d) => {
        if (d.id !== debtId) return d;
        const repayAmount = Math.max(0, Number(amount));
        const newRemaining = Math.max(0, d.remainingAmount - repayAmount);
        const repayment: DebtRepayment = {
          id: `repay_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          date: date || new Date().toISOString(),
          amount: repayAmount,
          remainingAfter: newRemaining,
          notes: note || '',
        };
        const nextPaidPeriods = (d.paidPeriods || 0) + 1;
        return {
          ...d,
          remainingAmount: newRemaining,
          paidPeriods: nextPaidPeriods,
          isSettled: newRemaining === 0,
          repayments: [repayment, ...(d.repayments || [])],
        };
      })
    );
    setCatMood('proud');
  };

  // --------------------------------------------------------------------------
  // 👥 多人分帳與代墊款 (Split Bills)
  // --------------------------------------------------------------------------
  const addSplitBill = (bill: SplitBill) => {
    const canonicalId = toUUID(bill.id || `split_${Date.now()}_${Math.random()}`);
    const newBill: SplitBill = {
      ...bill,
      id: canonicalId,
      userId: currentUser?.id || bill.userId,
      createdAt: bill.createdAt || new Date().toISOString(),
    };
    setSplitBills((prev) => [newBill, ...prev]);
    setCatMood('happy');
  };

  const updateSplitBill = (bill: SplitBill) => {
    setSplitBills((prev) => prev.map((b) => (b.id === bill.id ? bill : b)));
  };

  const deleteSplitBill = (id: string) => {
    setSplitBills((prev) => prev.filter((b) => b.id !== id));
  };

  const settleSplitParticipant = (billId: string, participantOrIndex: string | number) => {
    setSplitBills((prev) =>
      prev.map((b) => {
        if (b.id !== billId) return b;
        let updatedParticipants = [...(b.participants || [])];
        let updatedSettlements = [...(b.settlements || [])];

        if (typeof participantOrIndex === 'number') {
          if (updatedSettlements[participantOrIndex]) {
            const nextStatus = !updatedSettlements[participantOrIndex].isSettled;
            updatedSettlements[participantOrIndex] = {
              ...updatedSettlements[participantOrIndex],
              isSettled: nextStatus,
            };
          }
        } else {
          updatedParticipants = updatedParticipants.map((p) =>
            p.name === participantOrIndex ? { ...p, isSettled: !p.isSettled } : p
          );
        }

        const allSettlementsSettled = updatedSettlements.length > 0 && updatedSettlements.every((s) => s.isSettled);
        const allParticipantsSettled = updatedParticipants.length > 0 && updatedParticipants.every((p) => p.isSettled);
        const isSettled = allSettlementsSettled || allParticipantsSettled;

        return {
          ...b,
          participants: updatedParticipants,
          settlements: updatedSettlements,
          isSettled,
        };
      })
    );
    setCatMood('proud');
  };

  const settleEntireSplitBill = (billId: string) => {
    setSplitBills((prev) =>
      prev.map((b) => {
        if (b.id !== billId) return b;
        const nextSettled = !b.isSettled;
        return {
          ...b,
          isSettled: nextSettled,
          participants: (b.participants || []).map((p) => ({ ...p, isSettled: nextSettled })),
          settlements: (b.settlements || []).map((s) => ({ ...s, isSettled: nextSettled })),
        };
      })
    );
    setCatMood('proud');
  };

  // --------------------------------------------------------------------------
  // 🔄 每月固定支出與收入 (Recurring Items)
  // --------------------------------------------------------------------------
  const addRecurringItem = (item: RecurringItem) => {
    const canonicalId = toUUID(item.id || `rec_${Date.now()}_${Math.random()}`);
    const newItem: RecurringItem = {
      ...item,
      id: canonicalId,
      userId: currentUser?.id || item.userId,
    };
    setRecurringItems((prev) => [newItem, ...prev]);
    setCatMood('happy');
  };

  const updateRecurringItem = (item: RecurringItem) => {
    setRecurringItems((prev) => prev.map((r) => (r.id === item.id ? item : r)));
  };

  const deleteRecurringItem = (id: string) => {
    setRecurringItems((prev) => prev.filter((r) => r.id !== id));
  };

  const recordRecurringNow = async (id: string) => {
    const item = recurringItems.find((r) => r.id === id);
    if (!item) return;
    const currentMonth = new Date().toISOString().slice(0, 7);
    const newTx: Transaction = {
      id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      amount: item.amount,
      type: item.type,
      categoryName: item.categoryName,
      categoryIcon: item.emoji || (item.type === 'expense' ? '💸' : '💰'),
      categoryColorHex: item.colorHex || '#3B82F6',
      paymentMethodName: item.paymentMethodName || '一般帳戶',
      date: new Date().toISOString(),
      notes: `【每月固定】${item.title}${item.notes ? ` · ${item.notes}` : ''}`,
      valueScore: 8,
      isSharedWithFriends: false,
    };
    await addTransaction(newTx);
    setRecurringItems((prev) =>
      prev.map((r) => (r.id === id ? { ...r, lastRecordedMonth: currentMonth } : r))
    );
    setCatMood('proud');
  };

  // --------------------------------------------------------------------------
  // 💳 分期付款追蹤 (Installments Tracker)
  // --------------------------------------------------------------------------
  const addInstallment = (item: Installment) => {
    const canonicalId = toUUID(item.id || `inst_${Date.now()}_${Math.random()}`);
    const newItem: Installment = {
      ...item,
      id: canonicalId,
      userId: currentUser?.id || item.userId,
      isCompleted: item.paidPeriods >= item.totalPeriods,
    };
    setInstallments((prev) => [newItem, ...prev]);
    setCatMood('happy');
  };

  const updateInstallment = (item: Installment) => {
    setInstallments((prev) =>
      prev.map((inst) => {
        if (inst.id !== item.id) return inst;
        return {
          ...item,
          isCompleted: item.paidPeriods >= item.totalPeriods,
        };
      })
    );
  };

  const deleteInstallment = (id: string) => {
    setInstallments((prev) => prev.filter((inst) => inst.id !== id));
  };

  const payInstallmentPeriod = async (id: string) => {
    const item = installments.find((inst) => inst.id === id);
    if (!item || item.isCompleted) return;
    const nextPaid = item.paidPeriods + 1;
    const isNowCompleted = nextPaid >= item.totalPeriods;
    const newTx: Transaction = {
      id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      amount: item.periodAmount,
      type: 'expense',
      categoryName: '分期付款',
      categoryIcon: item.emoji || '💳',
      categoryColorHex: item.colorHex || '#6366F1',
      paymentMethodName: item.paymentMethodName || '信用卡',
      date: new Date().toISOString(),
      notes: `【分期扣款 第${nextPaid}/${item.totalPeriods}期】${item.title}${item.notes ? ` · ${item.notes}` : ''}`,
      valueScore: 8,
      isSharedWithFriends: false,
    };
    await addTransaction(newTx);
    setInstallments((prev) =>
      prev.map((inst) =>
        inst.id === id
          ? {
              ...inst,
              paidPeriods: nextPaid,
              isCompleted: isNowCompleted,
            }
          : inst
      )
    );
    setCatMood('proud');
  };

  // --------------------------------------------------------------------------
  // ⏳ 倒數日系統 (Countdowns Tracker)
  // --------------------------------------------------------------------------
  const addCountdown = (item: CountdownItem) => {
    const canonicalId = toUUID(item.id || `cd_${Date.now()}_${Math.random()}`);
    const newItem: CountdownItem = {
      ...item,
      id: canonicalId,
      userId: currentUser?.id || item.userId,
    };
    setCountdowns((prev) => [newItem, ...prev]);
    setCatMood('happy');
  };

  const updateCountdown = (item: CountdownItem) => {
    setCountdowns((prev) => prev.map((cd) => (cd.id === item.id ? item : cd)));
  };

  const deleteCountdown = (id: string) => {
    setCountdowns((prev) => prev.filter((cd) => cd.id !== id));
  };

  const togglePinCountdown = (id: string) => {
    setCountdowns((prev) =>
      prev.map((cd) => (cd.id === id ? { ...cd, isPinned: !cd.isPinned } : cd))
    );
  };

  const toggleCountdownTodo = (countdownId: string, todoItemId: string) => {
    setCountdowns((prev) =>
      prev.map((cd) => {
        if (cd.id === countdownId) {
          const updatedTodos = (cd.todos || []).map((t) =>
            t.id === todoItemId ? { ...t, isCompleted: !t.isCompleted } : t
          );
          return { ...cd, todos: updatedTodos };
        }
        return cd;
      })
    );
  };

  const addCountdownTodo = (countdownId: string, title: string) => {
    if (!title.trim()) return;
    const newTodo: CountdownTodoItem = {
      id: `ct_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: title.trim(),
      isCompleted: false,
    };
    setCountdowns((prev) =>
      prev.map((cd) => {
        if (cd.id === countdownId) {
          return { ...cd, todos: [...(cd.todos || []), newTodo] };
        }
        return cd;
      })
    );
  };

  const deleteCountdownTodo = (countdownId: string, todoItemId: string) => {
    setCountdowns((prev) =>
      prev.map((cd) => {
        if (cd.id === countdownId) {
          return { ...cd, todos: (cd.todos || []).filter((t) => t.id !== todoItemId) };
        }
        return cd;
      })
    );
  };

  // --------------------------------------------------------------------------
  // 🏺 夢想存錢筒 (Savings Jars / Wish List)
  // --------------------------------------------------------------------------
  const addSavingsJar = (jar: SavingsJar) => {
    const canonicalId = toUUID(jar.id || `jar_${Date.now()}_${Math.random()}`);
    const newJar: SavingsJar = {
      ...jar,
      id: canonicalId,
      deposits: jar.deposits || [],
      isCompleted: jar.currentAmount >= jar.targetAmount,
    };
    setSavingsJars((prev) => [newJar, ...prev]);
    setCatMood('happy');
  };

  const updateSavingsJar = (jar: SavingsJar) => {
    setSavingsJars((prev) =>
      prev.map((j) =>
        j.id === jar.id
          ? { ...jar, isCompleted: jar.currentAmount >= jar.targetAmount }
          : j
      )
    );
  };

  const deleteSavingsJar = (id: string) => {
    setSavingsJars((prev) => prev.filter((j) => j.id !== id));
  };

  const depositToSavingsJar = async (
    jarId: string,
    amount: number,
    note?: string,
    syncToExpense?: boolean
  ) => {
    const targetJar = savingsJars.find((j) => j.id === jarId);
    if (!targetJar || amount <= 0) return;

    const depositRecord: SavingsDeposit = {
      id: `dep_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      amount: Math.round(amount),
      date: new Date().toISOString().slice(0, 10),
      note: note || '夢想儲蓄存入',
    };

    setSavingsJars((prev) =>
      prev.map((j) => {
        if (j.id !== jarId) return j;
        const nextAmount = j.currentAmount + Math.round(amount);
        return {
          ...j,
          currentAmount: nextAmount,
          isCompleted: nextAmount >= j.targetAmount,
          deposits: [depositRecord, ...(j.deposits || [])],
        };
      })
    );

    if (syncToExpense) {
      const newTx: Transaction = {
        id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        amount: Math.round(amount),
        type: 'expense',
        categoryName: '夢想儲蓄',
        categoryIcon: targetJar.emoji || '🏺',
        categoryColorHex: targetJar.colorHex || '#8B5CF6',
        paymentMethodName: '儲蓄轉帳',
        date: new Date().toISOString(),
        notes: `【存入夢想存錢筒】${targetJar.title}${note ? ` · ${note}` : ''}`,
        valueScore: 10,
        isSharedWithFriends: false,
      };
      await addTransaction(newTx);
    }

    setCatMood('proud');
  };

  // --------------------------------------------------------------------------
  // 🎓 學分進度與期中期末成績試算 (GPA & Credit Tracker)
  // --------------------------------------------------------------------------
  const addCourseGrade = (item: CourseGradeItem) => {
    const canonicalId = toUUID(item.id || `cg_${Date.now()}_${Math.random()}`);
    setCourseGrades((prev) => [{ ...item, id: canonicalId }, ...prev]);
    setCatMood('happy');
  };

  const updateCourseGrade = (item: CourseGradeItem) => {
    setCourseGrades((prev) => prev.map((cg) => (cg.id === item.id ? item : cg)));
  };

  const deleteCourseGrade = (id: string) => {
    setCourseGrades((prev) => prev.filter((cg) => cg.id !== id));
  };

  const importCoursesToGrades = (): number => {
    const existingNames = new Set(
      courseGrades.map((cg) => cg.courseName.trim().toLowerCase())
    );
    const uniqueCourses = new Map<string, Course>();
    for (const c of courses) {
      const key = (c.name || '').trim().toLowerCase();
      if (key && !existingNames.has(key) && !uniqueCourses.has(key)) {
        uniqueCourses.set(key, c);
      }
    }

    if (uniqueCourses.size === 0) return 0;

    const newGradeItems: CourseGradeItem[] = Array.from(uniqueCourses.values()).map(
      (c, idx) => ({
        id: toUUID(`cg_imp_${Date.now()}_${idx}`),
        semester: '115-1',
        courseName: c.name,
        emoji: '📚',
        colorHex: c.colorHex || '#3B82F6',
        credits: 3,
        category: 'required',
        attendanceWeight: 30,
        midtermWeight: 30,
        finalWeight: 40,
        attendanceScore: null,
        midtermScore: null,
        finalScore: null,
        isPassed: true,
      })
    );

    setCourseGrades((prev) => [...newGradeItems, ...prev]);
    setCatMood('happy');
    return newGradeItems.length;
  };

  const updateGraduationTarget = (target: GraduationTarget) => {
    setGraduationTarget(target);
    setCatMood('happy');
  };

  // --------------------------------------------------------------------------
  // 💰 資產帳戶、股票基金投資與銷帳對帳平帳
  // --------------------------------------------------------------------------
  const addAssetAccount = (account: AssetAccount) => {
    const canonicalId = account.id || `acc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    setAssetAccounts((prev) => [...prev, { ...account, id: canonicalId, updatedAt: new Date().toISOString() }]);
    setCatMood('happy');
  };

  const updateAssetAccount = (account: AssetAccount) => {
    setAssetAccounts((prev) =>
      prev.map((acc) => (acc.id === account.id ? { ...account, updatedAt: new Date().toISOString() } : acc))
    );
  };

  const deleteAssetAccount = (id: string) => {
    setAssetAccounts((prev) => prev.filter((acc) => acc.id !== id));
  };

  const adjustAccountBalance = (accountId: string, newBalance: number, reason: string) => {
    setAssetAccounts((prev) => {
      const target = prev.find((a) => a.id === accountId);
      if (!target) return prev;
      const diff = Math.round((newBalance - target.balance) * 10) / 10;

      const adjRecord: BalanceAdjustmentRecord = {
        id: `adj_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        date: new Date().toISOString().slice(0, 10),
        accountId: target.id,
        accountName: target.name,
        beforeBalance: target.balance,
        afterBalance: newBalance,
        diffAmount: diff,
        reason: reason.trim() || '日常零錢對帳平帳',
        createdAt: new Date().toISOString(),
      };
      setBalanceAdjustments((rec) => [adjRecord, ...rec]);

      return prev.map((a) =>
        a.id === accountId
          ? { ...a, balance: newBalance, updatedAt: new Date().toISOString() }
          : a
      );
    });
    setCatMood('happy');
  };

  const addStockHolding = (accountId: string, stock: StockHoldingItem) => {
    const canonicalId = stock.id || `stk_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const newStock: StockHoldingItem = { ...stock, id: canonicalId, lastPriceUpdated: new Date().toISOString() };

    setAssetAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === accountId) {
          const nextStocks = [...(acc.stocks || []), newStock];
          const totalVal = nextStocks.reduce((sum, s) => sum + s.shares * s.currentPrice, 0);
          return { ...acc, stocks: nextStocks, balance: Math.round(totalVal), updatedAt: new Date().toISOString() };
        }
        return acc;
      })
    );
    setCatMood('happy');
  };

  const updateStockHolding = (accountId: string, stock: StockHoldingItem) => {
    setAssetAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === accountId) {
          const nextStocks = (acc.stocks || []).map((s) => (s.id === stock.id ? stock : s));
          const totalVal = nextStocks.reduce((sum, s) => sum + s.shares * s.currentPrice, 0);
          return { ...acc, stocks: nextStocks, balance: Math.round(totalVal), updatedAt: new Date().toISOString() };
        }
        return acc;
      })
    );
  };

  const deleteStockHolding = (accountId: string, stockId: string) => {
    setAssetAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === accountId) {
          const nextStocks = (acc.stocks || []).filter((s) => s.id !== stockId);
          const totalVal = nextStocks.reduce((sum, s) => sum + s.shares * s.currentPrice, 0);
          return { ...acc, stocks: nextStocks, balance: Math.round(totalVal), updatedAt: new Date().toISOString() };
        }
        return acc;
      })
    );
  };

  const refreshStockPrices = async () => {
    const allSymbols = new Set<string>();
    assetAccounts.forEach((acc) => {
      acc.stocks?.forEach((s) => allSymbols.add(s.symbol));
    });
    if (allSymbols.size === 0) return;

    try {
      const quotes = await batchFetchStockPrices(Array.from(allSymbols));
      setAssetAccounts((prev) =>
        prev.map((acc) => {
          if (acc.type === 'stock' && acc.stocks && acc.stocks.length > 0) {
            const updatedStocks = acc.stocks.map((s) => {
              const q = quotes[s.symbol];
              if (q && q.price > 0) {
                return {
                  ...s,
                  currentPrice: q.price,
                  name: q.name || s.name,
                  lastPriceUpdated: new Date().toISOString(),
                };
              }
              return s;
            });
            const totalVal = updatedStocks.reduce((sum, s) => sum + s.shares * s.currentPrice, 0);
            return { ...acc, stocks: updatedStocks, balance: Math.round(totalVal), updatedAt: new Date().toISOString() };
          }
          return acc;
        })
      );
      setCatMood('happy');
    } catch (err) {
      console.warn('Failed to refresh stock quotes:', err);
    }
  };

  const updateSurvivalSettings = (settings: SurvivalBudgetSettings) => {
    setSurvivalSettings(settings);
    setCatMood('happy');
  };

  // --------------------------------------------------------------------------
  // 📋 待選課程／未來排課心願單
  // --------------------------------------------------------------------------
  const addWishlistCourse = (item: CourseWishlistItem) => {
    const canonicalId = item.id || `cw_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    setCourseWishlist((prev) => [{ ...item, id: canonicalId, createdAt: new Date().toISOString() }, ...prev]);
    setCatMood('happy');
  };

  const updateWishlistCourse = (item: CourseWishlistItem) => {
    setCourseWishlist((prev) => prev.map((w) => (w.id === item.id ? item : w)));
  };

  const deleteWishlistCourse = (id: string) => {
    setCourseWishlist((prev) => prev.filter((w) => w.id !== id));
  };

  const convertWishlistToCourse = (wishlistId: string) => {
    const item = courseWishlist.find((w) => w.id === wishlistId);
    if (!item) return;

    const newCourse: Course = {
      id: `c_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: item.name,
      dayOfWeek: item.dayOfWeek,
      startTime: item.startTime,
      endTime: item.endTime,
      classroom: item.classroom || '',
      instructor: item.instructor || '',
      colorHex: item.colorHex || '#3B82F6',
      credits: item.credits,
      category: item.category,
      semester: item.targetSemester,
    };
    addCourse(newCourse);

    setCourseWishlist((prev) =>
      prev.map((w) => (w.id === wishlistId ? { ...w, status: 'enrolled' } : w))
    );
    setCatMood('happy');
  };

  const saveFriendRecord = (record: SavedFriendRecord) => {
    // 檢查是否有共享行事曆異動 (新增或刪除行程/待辦)
    const existing = savedFriendsRef.current.find(
      (f) => f.shareCode.toUpperCase() === record.shareCode.toUpperCase()
    );

    if (
      existing &&
      existing.cachedSchedule &&
      record.cachedSchedule &&
      settingsRef.current.pwaSharedCalendarNotifyEnabled !== false
    ) {
      const friendName = record.nickname || record.ownerName || '好友';
      const oldEvents = existing.cachedSchedule.calendarEventsData || [];
      const newEvents = record.cachedSchedule.calendarEventsData || [];

      // 檢查新增行程
      const addedEvent = newEvents.find((ne) => !oldEvents.some((oe) => oe.id === ne.id));
      if (addedEvent) {
        notifySharedCalendarChange('added', '行程', addedEvent.title, friendName);
      }
      // 檢查刪除行程
      const deletedEvent = oldEvents.find((oe) => !newEvents.some((ne) => ne.id === oe.id));
      if (deletedEvent) {
        notifySharedCalendarChange('deleted', '行程', deletedEvent.title, friendName);
      }

      // 檢查新增/刪除共享待辦
      const oldSharedTodos = (existing.cachedSchedule.todosData || []).filter((t) => t.isSharedToCalendar);
      const newSharedTodos = (record.cachedSchedule.todosData || []).filter((t) => t.isSharedToCalendar);

      const addedTodo = newSharedTodos.find((nt) => !oldSharedTodos.some((ot) => ot.id === nt.id));
      if (addedTodo) {
        notifySharedCalendarChange('added', '待辦', addedTodo.title, friendName);
      }
      const deletedTodo = oldSharedTodos.find((ot) => !newSharedTodos.some((nt) => nt.id === ot.id));
      if (deletedTodo) {
        notifySharedCalendarChange('deleted', '待辦', deletedTodo.title, friendName);
      }
    }

    setSavedFriends((prev) => {
      const filtered = prev.filter((f) => f.shareCode !== record.shareCode);
      const updated = [record, ...filtered];
      savedFriendsRef.current = updated;
      return updated;
    });
  };

  const removeFriendRecord = (shareCode: string) => {
    setSavedFriends((prev) => prev.filter((f) => f.shareCode !== shareCode));
  };

  const updateSettings = (partial: Partial<UserSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  const restoreBackupData = (imported: any): boolean => {
    try {
      if (!imported || typeof imported !== 'object') return false;
      const uid = activeUserIdRef.current;

      if (Array.isArray(imported.courses)) {
        setCourses(imported.courses);
        localStorage.setItem(getScopedKey(uid, 'courses'), JSON.stringify(imported.courses));
      }
      if (Array.isArray(imported.todos)) {
        setTodos(imported.todos);
        localStorage.setItem(getScopedKey(uid, 'todos'), JSON.stringify(imported.todos));
      }
      if (Array.isArray(imported.transactions)) {
        setTransactions(imported.transactions);
        localStorage.setItem(getScopedKey(uid, 'transactions'), JSON.stringify(imported.transactions));
      }
      if (Array.isArray(imported.calendarEvents)) {
        setCalendarEvents(imported.calendarEvents);
        localStorage.setItem(getScopedKey(uid, 'calendar_events'), JSON.stringify(imported.calendarEvents));
      }
      if (Array.isArray(imported.classPeriods)) {
        setClassPeriods(imported.classPeriods);
        localStorage.setItem(getScopedKey(uid, 'class_periods'), JSON.stringify(imported.classPeriods));
      }
      if (Array.isArray(imported.customExpenseCategories)) {
        setCustomExpenseCategories(imported.customExpenseCategories);
        localStorage.setItem(getScopedKey(uid, 'custom_expense_cats'), JSON.stringify(imported.customExpenseCategories));
      }
      if (Array.isArray(imported.customIncomeCategories)) {
        setCustomIncomeCategories(imported.customIncomeCategories);
        localStorage.setItem(getScopedKey(uid, 'custom_income_cats'), JSON.stringify(imported.customIncomeCategories));
      }
      if (Array.isArray(imported.customTodoCategories)) {
        setCustomTodoCategories(imported.customTodoCategories);
        localStorage.setItem(getScopedKey(uid, 'custom_todo_cats'), JSON.stringify(imported.customTodoCategories));
      }
      if (imported.settings && typeof imported.settings === 'object') {
        const nextSettings = { ...DEFAULT_SETTINGS, ...imported.settings };
        setSettings(nextSettings);
        localStorage.setItem(getScopedKey(uid, 'settings'), JSON.stringify(nextSettings));
      }
      return true;
    } catch (e) {
      console.error('Failed to restore backup data:', e);
      return false;
    }
  };

  const resetAllData = () => {
    const uid = activeUserIdRef.current;
    setCourses(INITIAL_COURSES);
    setTodos(INITIAL_TODOS);
    setTransactions(INITIAL_TRANSACTIONS);
    setCalendarEvents(INITIAL_CALENDAR_EVENTS);
    setClassPeriods(DEFAULT_CLASS_PERIODS);
    setCustomExpenseCategories(DEFAULT_EXPENSE_CATEGORIES);
    setCustomIncomeCategories(DEFAULT_INCOME_CATEGORIES);
    setCustomTodoCategories(DEFAULT_TODO_CATEGORIES);
    setSettings(DEFAULT_SETTINGS);
    setSavedFriends([]);

    localStorage.removeItem(getScopedKey(uid, 'courses'));
    localStorage.removeItem(getScopedKey(uid, 'todos'));
    localStorage.removeItem(getScopedKey(uid, 'transactions'));
    localStorage.removeItem(getScopedKey(uid, 'calendar_events'));
    localStorage.removeItem(getScopedKey(uid, 'class_periods'));
    localStorage.removeItem(getScopedKey(uid, 'saved_friends'));
    localStorage.removeItem(getScopedKey(uid, 'settings'));
    localStorage.removeItem(getScopedKey(uid, 'custom_expense_cats'));
    localStorage.removeItem(getScopedKey(uid, 'custom_income_cats'));
    localStorage.removeItem(getScopedKey(uid, 'custom_todo_cats'));
    localStorage.removeItem(getScopedKey(uid, 'debts'));
    localStorage.removeItem(getScopedKey(uid, 'split_bills'));
    localStorage.removeItem(getScopedKey(uid, 'installments'));
    localStorage.removeItem(getScopedKey(uid, 'recurring_items'));
    localStorage.removeItem(getScopedKey(uid, 'countdowns'));
    setDebts([]);
    setSplitBills([]);
    setInstallments([]);
    setRecurringItems([]);
    setCountdowns([]);
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        currentUser,
        setCurrentUser,
        updateCurrentUserDisplayName,
        logoutUser,
        isAuthModalOpen,
        setIsAuthModalOpen,
        isLineBotModalOpen,
        setIsLineBotModalOpen,
        isShareModalOpen,
        setIsShareModalOpen,
        isEventModalOpen,
        setIsEventModalOpen,
        isPeriodModalOpen,
        setIsPeriodModalOpen,
        isFortuneModalOpen,
        setIsFortuneModalOpen,
        isFoodRouletteOpen,
        setIsFoodRouletteOpen,
        isPomodoroOpen,
        setIsPomodoroOpen,
        restoreBackupData,
        resetAllData,
        eventToEdit,
        setEventToEdit,
        courses,
        todos,
        transactions,
        calendarEvents,
        classPeriods,
        updateClassPeriods,
        installments,
        addInstallment,
        updateInstallment,
        deleteInstallment,
        payInstallmentPeriod,
        recurringItems,
        addRecurringItem,
        updateRecurringItem,
        deleteRecurringItem,
        recordRecurringNow,
        countdowns,
        addCountdown,
        updateCountdown,
        deleteCountdown,
        togglePinCountdown,
        toggleCountdownTodo,
        addCountdownTodo,
        deleteCountdownTodo,
        savingsJars,
        addSavingsJar,
        updateSavingsJar,
        deleteSavingsJar,
        depositToSavingsJar,
        courseGrades,
        addCourseGrade,
        updateCourseGrade,
        deleteCourseGrade,
        importCoursesToGrades,
        graduationTarget,
        updateGraduationTarget,
        assetAccounts,
        addAssetAccount,
        updateAssetAccount,
        deleteAssetAccount,
        adjustAccountBalance,
        balanceAdjustments,
        addStockHolding,
        updateStockHolding,
        deleteStockHolding,
        refreshStockPrices,
        survivalSettings,
        updateSurvivalSettings,
        gpaScale,
        setGpaScale,
        courseWishlist,
        addWishlistCourse,
        updateWishlistCourse,
        deleteWishlistCourse,
        convertWishlistToCourse,
        splitBills,
        debts,
        addDebt,
        updateDebt,
        deleteDebt,
        repayDebt,
        addSplitBill,
        updateSplitBill,
        deleteSplitBill,
        settleSplitParticipant,
        settleEntireSplitBill,
        savedFriends,
        settings,
        isSyncing,
        isOnline,
        budgetInfo,
        catMood,
        setCatMood,
        customExpenseCategories,
        customIncomeCategories,
        customTodoCategories,
        addCustomCategory,
        updateCustomCategory,
        reorderCustomCategories,
        deleteCustomCategory,
        lastSyncedAt,
        nextSyncDisplay,
        triggerManualUpload,
        addCourse,
        updateCourse,
        deleteCourse,
        addTodo,
        updateTodo,
        toggleTodo,
        deleteTodo,
        addTransaction,
        deleteTransaction,
        addCalendarEvent,
        updateCalendarEvent,
        deleteCalendarEvent,
        saveFriendRecord,
        removeFriendRecord,
        updateSettings,
        rateFriendAccounting,
        syncWithSupabase,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
